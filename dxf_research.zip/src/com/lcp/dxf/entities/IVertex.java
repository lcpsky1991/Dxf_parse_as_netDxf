package com.lcp.dxf.entities;

public interface IVertex extends IEntityObject {
    VertexTypeFlags getFlags();
}
