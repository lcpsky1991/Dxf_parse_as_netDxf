package com.lcp.dxf.entities;


import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public class LwPolyLine extends DxfObject implements IPolyline{
      private static final EntityType TYPE = EntityType.LightWeightPolyline;
      @JsonProperty(value = "Vertexes")  
      private List<LwPolylineVertex> vertexes;
      @JsonProperty(value = "IsClosed")  
      private boolean isClosed;
      @JsonProperty(value = "Flags")  
      private String flags;
      @JsonProperty(value = "Layer")  
      private Layer layer;
      @JsonProperty(value = "Color")  
      private AciColor color;
      @JsonProperty(value = "LineType")  
      private LineType lineType;
      @JsonProperty(value = "Normal")  
      private Vector3f normal;
      @JsonProperty(value = "Elevation")  
      private float elevation;
      @JsonProperty(value = "Thickness")  
      private float thickness;
      @JsonProperty(value = "CodeName")  
      private String codeName;
      @JsonProperty(value = "Type")  
      public EntityType type;
	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return this.TYPE.value();
	}

	@Override
	public AciColor getColor() {
		// TODO Auto-generated method stub
		return this.color;
	}

	@Override
	public void setColor(AciColor color) {
		// TODO Auto-generated method stub
		this.color=color;
	}

	@Override
	public Layer getLayer() {
		// TODO Auto-generated method stub
		return this.layer;
	}

	@Override
	public void setLayer(Layer layer) {
		// TODO Auto-generated method stub
		this.layer=layer;
	}

	@Override
	public LineType getLineType() {
		// TODO Auto-generated method stub
		return this.lineType;
	}

	@Override
	public void setLineType(LineType lineType) {
		// TODO Auto-generated method stub
		this.lineType=lineType;
	}

	@Override
	public String getFlags() {
		// TODO Auto-generated method stub
		return PolylineTypeFlags.getFlags(Byte.valueOf(flags)).getNum();
	}
	public LwPolyLine()
{
    this.setCodeName(DxfObjectCode.LightWeightPolyline);
    this.vertexes = new ArrayList<LwPolylineVertex>();
    this.isClosed = false;
    this.layer = new Layer("0");
    this.color = new AciColor((short)256);
    this.lineType = new LineType("ByLayer");
    this.normal = new Vector3f(0, 0, 1);
    this.elevation = 0.0f;
    this.flags = PolylineTypeFlags.OpenPolyline.getNum();
}

	public List<LwPolylineVertex> getVertexes() {
		return vertexes;
	}

	public void setVertexes(List<LwPolylineVertex> vertexes) {
		this.vertexes = vertexes;
	}


	public boolean getIsClosed() {
        return isClosed;
    }

    public void setIsClosed(boolean isClosed) {
        this.isClosed = isClosed;
    }

    public Vector3f getNormal() {
		return normal;
	}

	public void setNormal(Vector3f normal) {
		this.normal = normal;
	}

	public float getElevation() {
		return elevation;
	}

	public void setElevation(float elevation) {
		this.elevation = elevation;
	}

	public float getThickness() {
		return thickness;
	}

	public void setThickness(float thickness) {
		this.thickness = thickness;
	}

	public void setFlags(PolylineTypeFlags flags) {
		this.flags = flags.getNum();
	}

	public Polyline toPolyline() {
		 List<PolylineVertex> polyVertexes = new ArrayList<PolylineVertex>();
         
         for (PolylineVertex polylineVertex : polyVertexes) {
        	 polyVertexes.add(new PolylineVertex(polylineVertex.getLocation()).setBeginThickness(polylineVertex.getBeginThickness())
        			 .setBulge(polylineVertex.getBulge()).setEndThickness(polylineVertex.getBulge())
);
		}

         return new Polyline(polyVertexes, this.isClosed);
	}

	@Override
	public String toString() {
		return "LwPolyLine [vertexes=" + vertexes + ", isClosed=" + isClosed + ", flags=" + flags + ", layer=" + layer
				+ ", color=" + color + ", lineType=" + lineType + ", normal=" + normal + ", elevation=" + elevation
				+ ", thickness=" + thickness + "]";
	}

	public String getCodeName() {
		return codeName;
	}

	public DxfObject setCodeName(String codeName) {
		this.codeName = codeName;
		return this;
	}

}
