package com.lcp.dxf.entities;

public interface IPolyline extends IEntityObject{
    String getFlags();
}
