package com.lcp.dxf.entities;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public class Solid extends DxfObject implements IEntityObject{
    private static EntityType TYPE = EntityType.Solid;
    private Vector3f firstVertex;
    private Vector3f secondVertex;
    private Vector3f thirdVertex;
    private Vector3f fourthVertex;
    private float thickness;
    private Vector3f normal;
    private Layer layer;
    private AciColor color;
    private LineType lineType;
    private String codeName;
    public static EntityType getTYPE() {
        return TYPE;
    }
    public static void setTYPE(EntityType tYPE) {
        TYPE = tYPE;
    }
    public Vector3f getFirstVertex() {
        return firstVertex;
    }
    public void setFirstVertex(Vector3f firstVertex) {
        this.firstVertex = firstVertex;
    }
    public Vector3f getSecondVertex() {
        return secondVertex;
    }
    public void setSecondVertex(Vector3f secondVertex) {
        this.secondVertex = secondVertex;
    }
    public Vector3f getThirdVertex() {
        return thirdVertex;
    }
    public void setThirdVertex(Vector3f thirdVertex) {
        this.thirdVertex = thirdVertex;
    }
    public Vector3f getFourthVertex() {
        return fourthVertex;
    }
    public void setFourthVertex(Vector3f fourthVertex) {
        this.fourthVertex = fourthVertex;
    }
    public float getThickness() {
        return thickness;
    }
    public void setThickness(float thickness) {
        this.thickness = thickness;
    }
    public Vector3f getNormal() {
        return normal;
    }
    public void setNormal(Vector3f normal) {
        this.normal = normal;
    }
    public Layer getLayer() {
        return layer;
    }
    public void setLayer(Layer layer) {
        this.layer = layer;
    }
    public AciColor getColor() {
        return color;
    }
    public void setColor(AciColor color) {
        this.color = color;
    }
    public LineType getLineType() {
        return lineType;
    }
    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }
    @Override
    public String getType() {
        // TODO Auto-generated method stub
        return this.TYPE.value();
    }
	public String getCodeName() {
		return codeName;
	}
	public DxfObject setCodeName(String codeName) {
		this.codeName = codeName;
	    return this;
	}
    
}
