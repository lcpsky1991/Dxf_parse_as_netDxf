package com.lcp.dxf.entities;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public class Circle extends DxfObject implements IEntityObject,Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	 @JsonProperty(value = "Center")  
	private Vector3f center;
	 @JsonProperty(value = "Radius")  
	 private float radius;
	 @JsonProperty(value = "Thickness")  
	private float thickness;
	private EntityType TYPE = EntityType.Circle;
	 @JsonProperty(value = "Color")  
	 private AciColor color;
	 @JsonProperty(value = "Layer")  
	private Layer layer;
	 @JsonProperty(value = "LineType")  
	private LineType lineType;
	 @JsonProperty(value = "Normal")  
	private Vector3f normal;
	 @JsonProperty(value = "CodeName")  
	private String codeName;
	  @JsonProperty(value = "Type")  
	    private String type;
	public Circle(String codeName) {
        super(codeName);
    }
    public Circle() {
        this.setCodeName(DxfObjectCode.Circle);
        this.center = new Vector3f(0, 0, 0);
        this.radius = 1.0f;
        this.thickness = 0.0f;
        this.layer = new Layer("0");
        this.color = new AciColor((short)256);
        this.lineType = new LineType("ByLayer");
        this.normal = new Vector3f(0, 0, 1);
    }
    
    public Vector3f getCenter() {
        return center;
    }
    public void setCenter(Vector3f center) {
        this.center = center;
    }
    public float getRadius() {
        return radius;
    }
    public void setRadius(float radius) {
        this.radius = radius;
    }
    public float getThickness() {
        return thickness;
    }
    public void setThickness(float thickness) {
        this.thickness = thickness;
    }
    public Layer getLayer() {
        return layer;
    }
    public void setLayer(Layer layer) {
        this.layer = layer;
    }
    public AciColor getColor() {
        return color;
    }
    public void setColor(AciColor color) {
        this.color = color;
    }
    public LineType getLineType() {
        return lineType;
    }
    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }
    public Vector3f getNormal() {
        return normal;
    }
    public void setNormal(Vector3f normal) {
        this.normal = normal;
    }
	@Override
	public String toString() {
		return "Circle [center=" + center + ", radius=" + radius + ", thickness=" + thickness + ", type=" + TYPE
				+ ", color=" + color + ", layer=" + layer + ", lineType=" + lineType + ", normal=" + normal + "]";
	}
	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return this.TYPE.value();
	}
	public String getCodeName() {
		return codeName;
	}
	public DxfObject setCodeName(String codeName) {
		this.codeName = codeName;
		return this;
	}
   
}
