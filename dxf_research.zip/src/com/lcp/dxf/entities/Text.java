package com.lcp.dxf.entities;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;
import com.lcp.dxf.base.TextAlignment;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;
import com.lcp.dxf.tables.TextStyle;

public class Text extends DxfObject implements IEntityObject{
    public Text(String codeName) {
        super(codeName);
        // TODO Auto-generated constructor stub
    }
    @JsonProperty(value = "Rotation")  
    private float rotation;
    @JsonProperty(value = "Height")  
    private float height;
    @JsonProperty(value = "WidthFactor")  
    private float widthFactor;
    @JsonProperty(value = "ObliqueAngle")  
    private float obliqueAngle;
    @JsonProperty(value = "Style")  
    private TextStyle style;
    @JsonProperty(value = "BasePoint")  
    private Vector3f basePoint;
    @JsonProperty(value = "Alignment")  
    private TextAlignment alignment;
    private  EntityType Type = EntityType.Text;
    @JsonProperty(value = "Value")  
    private String value;
    @JsonProperty(value = "Thickness")  
    private float thickness;
    @JsonProperty(value = "Color")  
    private AciColor color;
    @JsonProperty(value = "Layer")  
    private Layer layer;
    @JsonProperty(value = "LineType")  
    private LineType lineType;
    @JsonProperty(value = "Normal")  
    private Vector3f normal;
    @JsonProperty(value = "CodeName")  
    private String codeName;
    @JsonProperty(value = "Type")  
    private String type;
    @Override
    public String getType() {
        // TODO Auto-generated method stub
        return Type.value();
    }
    @Override
    public AciColor getColor() {
        // TODO Auto-generated method stub
        return this.color;
    }
    @Override
    public void setColor(AciColor color) {
        // TODO Auto-generated method stub
        this.color = color;
    }
    @Override
    public Layer getLayer() {
        // TODO Auto-generated method stub
        return this.layer;
    }
    @Override
    public void setLayer(Layer layer) {
        // TODO Auto-generated method stub
        this.layer = layer;
    }
    @Override
    public LineType getLineType() {
        // TODO Auto-generated method stub
        return this.lineType;
    }
    @Override
    public void setLineType(LineType lineType) {
        // TODO Auto-generated method stub
        this.lineType = lineType;
    }
    public float getRotation() {
        return rotation;
    }
    public void setRotation(float rotation) {
        this.rotation = rotation;
    }
    public float getHeight() {
        return height;
    }
    public void setHeight(float height) {
        this.height = height;
    }
    public float getWidthFactor() {
        return widthFactor;
    }
    public void setWidthFactor(float widthFactor) {
        this.widthFactor = widthFactor;
    }
    public float getObliqueAngle() {
        return obliqueAngle;
    }
    public void setObliqueAngle(float obliqueAngle) {
        this.obliqueAngle = obliqueAngle;
    }
    public TextStyle getStyle() {
        return style;
    }
    public void setStyle(TextStyle style) {
        this.style = style;
    }
    public Vector3f getBasePoint() {
        return basePoint;
    }
    public void setBasePoint(Vector3f basePoint) {
        this.basePoint = basePoint;
    }
    public TextAlignment getAlignment() {
        return alignment;
    }
    public void setAlignment(TextAlignment alignment) {
        this.alignment = alignment;
    }
    public Vector3f getNormal() {
        return normal;
    }
    public void setNormal(Vector3f normal) {
        this.normal = normal;
    }
    public void setType(String type) {
        this.type = type;
    }
    public Text()
{
    this.value = "";
    this.basePoint = new Vector3f(0, 0, 0);
    this.alignment = TextAlignment.BaselineLeft;
    this.layer = new Layer("0");
    this.color =  new AciColor((short)256);
    this.lineType = new LineType("ByLayer");
    this.normal = new Vector3f(0, 0, 1);
    this.style = new TextStyle("Standard", "simplex");
    this.rotation = 0.0f;
    this.height = 0.0f;
    this.widthFactor = 1.0f;
    this.obliqueAngle = 0.0f;
    this.setCodeName(DxfObjectCode.Text);
}

/// <summary>
/// Initializes a new instance of the <c>Text</c> class.
/// </summary>
/// <param name="text">Text string.</param>
/// <param name="basePoint">Text base <see cref="Vector3f">point</see>.</param>
/// <param name="height">Text height.</param>
public Text(String text, Vector3f basePoint, float height)
{
    this.value = text;
    this.basePoint = basePoint;
    this.alignment = TextAlignment.BaselineLeft;
    this.layer = new Layer("0");
    this.color = new AciColor((short)256);
    this.lineType = new LineType("ByLayer");
    this.normal = new Vector3f(0, 0, 1);
    this.style = new TextStyle("Standard", "simplex");
    this.rotation = 0.0f;
    this.height = height;
    this.widthFactor = 1.0f;
    this.obliqueAngle = 0.0f;
}
public Text(String text, Vector3f basePoint, float height, TextStyle style)
{
this.value = text;
this.basePoint = basePoint;
this.alignment = TextAlignment.BaselineLeft;
this.layer = new Layer("0");
this.color = new AciColor((short)256);
this.lineType = new LineType("ByLayer");
this.normal = new Vector3f(0, 0, 1);
this.style = style;
this.height = height;
this.widthFactor = style.getWidthFactor();
this.obliqueAngle = style.getObliqueAngle();
this.rotation = 0.0f;
}

public String getValue() {
    return value;
}
public void setValue(String value) {
    this.value = value;
}
@Override
public String toString() {
	return "Text [rotation=" + rotation + ", height=" + height + ", widthFactor=" + widthFactor + ", obliqueAngle="
			+ obliqueAngle + ", style=" + style + ", basePoint=" + basePoint + ", alignment=" + alignment + ", normal="
			+ normal + ", type=" + type + ", color=" + color + ", layer=" + layer + ", lineType=" + lineType
			+ ", value=" + value + "]";
}
public String getCodeName() {
	return codeName;
}
public DxfObject setCodeName(String codeName) {
	this.codeName = codeName;
	return this;
}


}
