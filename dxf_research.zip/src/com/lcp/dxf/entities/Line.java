package com.lcp.dxf.entities;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public class Line extends DxfObject implements IEntityObject{
    private EntityType TYPE = EntityType.Line;
    @JsonProperty(value = "StartPoint")  
    private Vector3f startPoint;
    @JsonProperty(value = "EndPoint")  
    private Vector3f endPoint;
    @JsonProperty(value = "Thickness")  
    private float thickness;
    @JsonProperty(value = "Color")  
    private AciColor color;
    @JsonProperty(value = "Layer")  
    private Layer layer;
    @JsonProperty(value = "LineType")  
    private LineType lineType;
    @JsonProperty(value = "Normal")  
    private Vector3f normal;
    @JsonProperty(value = "CodeName")  
    private String codeName;
    @JsonProperty(value = "Type")  
    private String type;

    public Vector3f getStartPoint() {
        return startPoint;
    }
    public void setStartPoint(Vector3f startPoint) {
        this.startPoint = startPoint;
    }
    public Vector3f getEndPoint() {
        return endPoint;
    }
    public void setEndPoint(Vector3f endPoint) {
        this.endPoint = endPoint;
    }
    public float getThickness() {
        return thickness;
    }
    public void setThickness(float thickness) {
        this.thickness = thickness;
    }
    public AciColor getColor() {
        return color;
    }
    public void setColor(AciColor color) {
        this.color = color;
    }
    public Layer getLayer() {
        return layer;
    }
    public void setLayer(Layer layer) {
        this.layer = layer;
    }
    public LineType getLineType() {
        return lineType;
    }
    public void setLineType(LineType lineType) {
        this.lineType = lineType;  
    }
    public Vector3f getNormal() {
        return normal;
    }
    public void setNormal(Vector3f normal) {
        this.normal = normal;
    }
    @Override
    public String getType() {
        // TODO Auto-generated method stub
        return this.TYPE.value();
    }
    public Line()
   
{
    this.setCodeName(DxfObjectCode.Line);
    this.startPoint = new Vector3f(0,0,0);
    this.endPoint = new Vector3f(0,0,0);
    this.thickness = 0.0f;
    this.layer = new Layer("0");
    this.color = new AciColor((short)256);
    this.lineType = new LineType("ByLayer");
    this.normal = new Vector3f(0, 0, 1);
}
	@Override
	public String toString() {
		return "Line [TYPE=" + TYPE + ", startPoint=" + startPoint + ", endPoint=" + endPoint + ", thickness="
				+ thickness + ", color=" + color + ", layer=" + layer + ", lineType=" + lineType + ", normal=" + normal
				+ "]";
	}
	public String getCodeName() {
		return codeName;
	}
	public DxfObject setCodeName(String codeName) {
		this.codeName = codeName;
		return this;
	}
    
}
