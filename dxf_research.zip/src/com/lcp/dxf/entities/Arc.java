package com.lcp.dxf.entities;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public class Arc extends DxfObject implements IEntityObject {
	private EntityType TYPE = EntityType.Arc;
	 @JsonProperty(value = "Center")  
	private Vector3f center;
	 @JsonProperty(value = "Radius")  
	private float radius;
	 @JsonProperty(value = "StartAngle")  
	private float startAngle;
	 @JsonProperty(value = "EndAngle")  
	private float endAngle;
	 @JsonProperty(value = "Thickness")  
	private float thickness;
	 @JsonProperty(value = "Normal")  
	private Vector3f normal;
	 @JsonProperty(value = "Color")  
	private AciColor color;
	 @JsonProperty(value = "Layer")  
	private Layer layer;
	 @JsonProperty(value = "LineType")  
	private LineType lineType;
	 @JsonProperty(value = "CodeName")  
	private String codeName;
	  @JsonProperty(value = "Type")  
          private String type;
	public Vector3f getCenter() {
		return center;
	}

	public void setCenter(Vector3f center) {
		this.center = center;
	}

	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	public float getStartAngle() {
		return startAngle;
	}

	public void setStartAngle(float startAngle) {
		this.startAngle = startAngle;
	}

	public float getEndAngle() {
		return endAngle;
	}

	public void setEndAngle(float endAngle) {
		this.endAngle = endAngle;
	}

	public float getThickness() {
		return thickness;
	}

	public void setThickness(float thickness) {
		this.thickness = thickness;
	}

	public Vector3f getNormal() {
		return normal;
	}

	public void setNormal(Vector3f normal) {
		this.normal = normal;
	}

	public AciColor getColor() {
		return color;
	}

	public void setColor(AciColor color) {
		this.color = color;
	}

	public Layer getLayer() {
		return layer;
	}

	public void setLayer(Layer layer) {
		this.layer = layer;
	}

	public LineType getLineType() {
		return lineType;
	}

	public void setLineType(LineType lineType) {
		this.lineType = lineType;
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return this.TYPE.value();
	}

	@Override
	public String toString() {
		return "Arc [TYPE=" + TYPE + ", center=" + center + ", radius=" + radius + ", startAngle=" + startAngle
				+ ", endAngle=" + endAngle + ", thickness=" + thickness + ", normal=" + normal + ", color=" + color
				+ ", layer=" + layer + ", lineType=" + lineType + "]";
	}

	public Arc() {
		super();
		this.setCodeName(DxfObjectCode.Arc);
		this.radius = 0.0f;
		this.startAngle = 0.0f;
		this.endAngle = 0.0f;
		this.thickness = 0.0f;
		this.thickness = 0.0f;
		this.center=new Vector3f(0, 0, 0);
		this.layer = new Layer("0");
		this.color = new AciColor((short) 256);
		this.lineType = new LineType("ByLayer");
		this.normal = new Vector3f(0, 0, 1);
	}

	public String getCodeName() {
		return codeName;
	}

	public DxfObject setCodeName(String codeName) {
		this.codeName = codeName;
		return this;
	}

}
