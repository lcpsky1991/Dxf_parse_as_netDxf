package com.lcp.dxf.entities;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public class Point extends DxfObject implements IEntityObject{
    
    private static EntityType TYPE = EntityType.Point;
    
    @JsonProperty(value = "Location") 
    private Vector3f location;
    @JsonProperty(value = "Thickness") 
    private float thickness;
    @JsonProperty(value = "Layer") 
    private Layer layer;
    @JsonProperty(value = "Color") 
    private AciColor color;
    @JsonProperty(value = "LineType") 
    private LineType lineType;
    @JsonProperty(value = "Normal") 
    private Vector3f normal;
    @JsonProperty(value = "Type")  
    private String type;
    public Vector3f getLocation() {
        return location;
    }
    public void setLocation(Vector3f location) {
        this.location = location;
    }
    public float getThickness() {
        return thickness;
    }
    public void setThickness(float thickness) {
        this.thickness = thickness;
    }
    public Layer getLayer() {
        return layer;
    }
    public void setLayer(Layer layer) {
        this.layer = layer;
    }
    public AciColor getColor() {
        return color;
    }
    public void setColor(AciColor color) {
        this.color = color;
    }
    public LineType getLineType() {
        return lineType;
    }
    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }
    public Vector3f getNormal() {
        return normal;
    }
    public void setNormal(Vector3f normal) {
        this.normal = normal;
    }
    public static EntityType getTYPE() {
        return TYPE;
    }
    public static void setTYPE(EntityType tYPE) {
        TYPE = tYPE;
    }
    @Override
    public String getType() {
        // TODO Auto-generated method stub
        return TYPE.value();
    }
    public Point()
{
    this.codeName = DxfObjectCode.Point;
    this.location = new Vector3f(0, 0, 0);
    this.thickness = 0.0f;
    this.layer = new Layer();
    this.color = new AciColor(Short.valueOf("256"));
    this.lineType = LineType.ByLayer;
    this.normal = new Vector3f(0, 0, 1);
}
	@Override
	public String toString() {
		return "Point [location=" + location + ", thickness=" + thickness + ", layer=" + layer + ", color=" + color
				+ ", lineType=" + lineType + ", normal=" + normal + "]";
	}
  
    
}
