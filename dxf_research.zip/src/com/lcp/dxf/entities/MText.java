package com.lcp.dxf.entities;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;
import com.lcp.dxf.base.TextAlignment;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;
import com.lcp.dxf.tables.TextStyle;

public class MText extends DxfObject implements IEntityObject{
    public MText(String codeName) {
        super();
        this.setCodeName(DxfObjectCode.Text);
        // TODO Auto-generated constructor stub
    }
    public MText() {
        this.codeName=DxfObjectCode.Text;
        this.value ="";
        this.basePoint = new Vector3f(0, 0, 0);
        this.setAlignment(TextAlignment.BaselineLeft);
        this.layer = new Layer("0");
        this.color = new AciColor((short)256);
        this.lineType = new LineType("ByLayer");
        this.normal = new Vector3f(0, 0, 1);
        this.setStyle(new TextStyle("Standard", "simplex"));
        this.rotation = 0.0f;
        this.height = 0.0f;
        this.widthFactor = 1.0f;
        this.obliqueAngle = 0.0f;
    }
    @JsonProperty(value = "Rotation")  
    private float rotation;
    @JsonProperty(value = "Height")  
    private float height;
    @JsonProperty(value = "WidthFactor")  
    private float widthFactor;
    @JsonProperty(value = "ObliqueAngle")  
    private float obliqueAngle;
    @JsonProperty(value = "BasePoint")  
    private Vector3f basePoint;
    @JsonProperty(value = "Value")  
    private String value;
    @JsonProperty(value = "Type")  
    private  EntityType type = EntityType.Text;
    @JsonProperty(value = "Color")  
    private AciColor color;
    @JsonProperty(value = "Layer")  
    private Layer layer;
    @JsonProperty(value = "LineType")  
    private LineType lineType;
    @JsonProperty(value = "Alignment")  
    private TextAlignment alignment;
    @JsonProperty(value = "Normal")  
    private Vector3f normal;
    @JsonProperty(value = "Style")  
    private TextStyle style;
    @JsonProperty(value = "CodeName")  
    private String codeName;
    public float getRotation() {
        return rotation;
    }
    public void setRotation(float rotation) {
        this.rotation = rotation;
    }
    public float getHeight() {
        return height;
    }
    public void setHeight(float height) {
        this.height = height;
    }
    public float getWidthFactor() {
        return widthFactor;
    }
    public void setWidthFactor(float widthFactor) {
        this.widthFactor = widthFactor;
    }
    public float getObliqueAngle() {
        return obliqueAngle;
    }
    public void setObliqueAngle(float obliqueAngle) {
        this.obliqueAngle = obliqueAngle;
    }
    public Vector3f getBasePoint() {
        return basePoint;
    }
    public void setBasePoint(Vector3f basePoint) {
        this.basePoint = basePoint;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public String getType() {
        return type.value();
    }
    public void setType(EntityType type) {
        this.type = type;
    }
    public AciColor getColor() {
        return color;
    }
    public void setColor(AciColor color) {
        this.color = color;
    }
    public Layer getLayer() {
        return layer;
    }
    public void setLayer(Layer layer) {
        this.layer = layer;
    }
    public LineType getLineType() {
        return lineType;
    }
    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }
    public Vector3f getNormal() {
        return normal;
    }
    public void setNormal(Vector3f normal) {
        this.normal = normal;
    }
    public TextStyle getStyle() {
        return style;
    }
    public void setStyle(TextStyle style) {
        this.style = style;
    }
    public TextAlignment getAlignment() {
        return alignment;
    }
    public void setAlignment(TextAlignment alignment) {
        this.alignment = alignment;
    }
	@Override
	public String toString() {
		return "MText [rotation=" + rotation + ", height=" + height + ", widthFactor=" + widthFactor + ", obliqueAngle="
				+ obliqueAngle + ", basePoint=" + basePoint + ", value=" + value + ", type=" + type + ", color=" + color
				+ ", layer=" + layer + ", lineType=" + lineType + ", alignment=" + alignment + ", normal=" + normal
				+ ", style=" + style + "]";
	}
	public String getCodeName() {
		return codeName;
	}
	public DxfObject setCodeName(String codeName) {
		this.codeName = codeName;
		return this;
	}
  
    
}
