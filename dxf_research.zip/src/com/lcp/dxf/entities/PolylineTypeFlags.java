package com.lcp.dxf.entities;

public enum PolylineTypeFlags {
    OpenPolyline((byte)0),
    ClosedPolylineOrClosedPolygonMeshInM((byte)1),
    CurveFit((byte)2),
    SplineFit((byte)4),
    Polyline3D((byte)8),
    PolygonMesh((byte)16),
    ClosedPolygonMeshInN((byte)32),
    PolyfaceMesh((byte)64),
    ContinuousLineTypePatter((byte)128);
    private byte num;
    private PolylineTypeFlags(byte num){
        this.num = num;
    }
    public String getNum(){
        return String.valueOf(this.num);
    }
    public static PolylineTypeFlags getFlags(Byte num){
        switch (num) {
        case (byte)0:
            return OpenPolyline;
        case (byte)1:
            return ClosedPolylineOrClosedPolygonMeshInM;
        case (byte)32:
            return ClosedPolygonMeshInN;
        default:
            break;
        }
        return null;
    }
}
