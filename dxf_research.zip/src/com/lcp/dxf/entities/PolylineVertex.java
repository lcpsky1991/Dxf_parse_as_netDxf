package com.lcp.dxf.entities;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;
import com.lcp.dxf.base.Vector2f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public class PolylineVertex extends DxfObject implements IVertex{
    
    protected static EntityType TYPE = EntityType.PolylineVertex;
    protected VertexTypeFlags flags;
    protected Vector2f location;
    protected float beginThickness;
    protected float endThickness;
    protected float bulge;
    protected AciColor color;
    protected Layer layer;
    protected LineType lineType;
    
    public PolylineVertex()
{
    this.codeName = DxfObjectCode.Vertex;
    this.flags = VertexTypeFlags.PolylineVertex;
    this.location = new Vector2f(0, 0);
    this.layer = new Layer("0");
    this.color = new AciColor((short)256);
    this.lineType = new LineType("ByLayer");
    this.bulge = 0.0f;
    this.beginThickness = 0.0f;
    this.endThickness = 0.0f;
}
    public PolylineVertex(Vector2f location)
{
    this.flags = VertexTypeFlags.PolylineVertex;
    this.location = location;
    this.layer = new Layer("0");
    this.color = new AciColor((short)256);
    this.lineType = new LineType("ByLayer");
    this.bulge = 0.0f;
    this.beginThickness = 0.0f;
    this.endThickness = 0.0f;
}

    public Vector2f getLocation() {
		return location;
	}
	public void setLocation(Vector2f location) {
		this.location = location;
	}
	public float getBeginThickness() {
		return beginThickness;
	}
	public PolylineVertex setBeginThickness(float beginThickness) {
		this.beginThickness = beginThickness;
		return this;
	}
	public float getEndThickness() {
		return endThickness;
	}
	public PolylineVertex setEndThickness(float endThickness) {
		this.endThickness = endThickness;
		return this;
	}
	public float getBulge() {
		return bulge;
	}
	public PolylineVertex setBulge(float bulge) {
		this.bulge = bulge;
		return this;
	}
	@Override
    public String getType() {
        // TODO Auto-generated method stub
        return TYPE.value();
    }

    @Override
    public AciColor getColor() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setColor(AciColor color) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public Layer getLayer() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setLayer(Layer layer) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public LineType getLineType() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setLineType(LineType lineType) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public VertexTypeFlags getFlags() {
        // TODO Auto-generated method stub
        return null;
    }

}
