package com.lcp.dxf.entities;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public class Ellipse extends DxfObject implements IEntityObject{
    private EntityType TYPE = EntityType.Line;

    private Vector3f startPoint;

    private Vector3f endPoint;

    private float thickness;

    private AciColor color;

    private Layer layer;

    private LineType lineType;

    private Vector3f normal;

    public EntityType getTYPE() {
        return TYPE;
    }

    public void setTYPE(EntityType tYPE) {
        TYPE = tYPE;
    }

    public Vector3f getStartPoint() {
        return startPoint;
    }

    public void setStartPoint(Vector3f startPoint) {
        this.startPoint = startPoint;
    }

    public Vector3f getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(Vector3f endPoint) {
        this.endPoint = endPoint;
    }

    public float getThickness() {
        return thickness;
    }

    public void setThickness(float thickness) {
        this.thickness = thickness;
    }

    public AciColor getColor() {
        return color;
    }

    public void setColor(AciColor color) {
        this.color = color;
    }

    public Layer getLayer() {
        return layer;
    }

    public void setLayer(Layer layer) {
        this.layer = layer;
    }

    public LineType getLineType() {
        return lineType;
    }

    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }

    public Vector3f getNormal() {
        return normal;
    }

    public void setNormal(Vector3f normal) {
        this.normal = normal;
    }

    @Override
    public String getType() {
        // TODO Auto-generated method stub
        return this.TYPE.value();
    }

	@Override
	public String toString() {
		return "Ellipse [TYPE=" + TYPE + ", startPoint=" + startPoint + ", endPoint=" + endPoint + ", thickness="
				+ thickness + ", color=" + color + ", layer=" + layer + ", lineType=" + lineType + ", normal=" + normal
				+ "]";
	}
    
    
}
