package com.lcp.dxf.entities;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.Vector2f;

public class LwPolylineVertex {
    protected final EntityType TYPE1 = EntityType.LightWeightPolylineVertex;
    @JsonProperty(value = "Location")  
    protected Vector2f location;
    @JsonProperty(value = "BeginThickness")  
    protected float beginThickness;
    @JsonProperty(value = "EndThickness")  
    protected float endThickness;
    @JsonProperty(value = "Bulge")  
    protected float bulge;
    @JsonProperty(value = "Type")  
    public String type;
    public LwPolylineVertex() {
        this.location = new Vector2f(0, 0);
        this.bulge = 0.0f;
        this.beginThickness = 0.0f;
        this.endThickness = 0.0f;
    }

    public String getType() {
        return TYPE1.value();
    }

    public void setType(String type) {
        this.type = type;
    }

    public LwPolylineVertex(Vector2f location) {
        this.location = location;
        this.bulge = 0.0f;
        this.beginThickness = 0.0f;
        this.endThickness = 0.0f;
    }

    public LwPolylineVertex(float x, float y) {
        this.location = new Vector2f(x, y);
        this.bulge = 0.0f;
        this.beginThickness = 0.0f;
        this.endThickness = 0.0f;
    }

    public Vector2f getLocation() {
        return location;
    }

    public void setLocation(Vector2f location) {
        this.location = location;
    }

    public float getBeginThickness() {
        return beginThickness;
    }

    public void setBeginThickness(float beginThickness) {
        this.beginThickness = beginThickness;
    }

    public float getEndThickness() {
        return endThickness;
    }

    public void setEndThickness(float endThickness) {
        this.endThickness = endThickness;
    }

    public float getBulge() {
        return bulge;
    }

    public void setBulge(float bulge) {
        this.bulge = bulge;
    }


}
