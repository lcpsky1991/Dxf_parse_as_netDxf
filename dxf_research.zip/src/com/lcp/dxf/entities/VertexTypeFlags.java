package com.lcp.dxf.entities;

public enum VertexTypeFlags {
    /// <summary>
    /// 2d polyline vertex
    /// </summary>
    PolylineVertex((byte)0),
    /// <summary>
    /// Extra vertex created by curve-fitting
    /// </summary>
    CurveFittingExtraVertex((byte)1),
    /// <summary>
    /// Curve-fit tangent defined for this vertex.
    /// A curve-fit tangent direction of 0 may be omitted from DXF output but is significant if this bit is set,
    /// </summary>
    CurveFitTangent((byte)2),
    /// <summary>(byte)
    /// Not used
    /// </summary>
    NotUsed((byte)4),
    /// <summary>
    /// Spline vertex created by spline-fitting
    /// </summary>
    SplineVertexFromSplineFitting((byte)8),
    /// <summary>
    /// Spline frame control point
    /// </summary>
    SplineFrameControlPoint((byte)16),
    /// <summary>
    /// 3D polyline vertex
    /// </summary>
    Polyline3dVertex((byte)32),
    /// <summary>
    /// 3D polygon mesh
    /// </summary>
    Polygon3dMesh((byte)64),
    /// <summary>
    /// Polyface mesh vertex
    /// </summary>
    PolyfaceMeshVertex((byte)128);
    
    private final byte num;
    private VertexTypeFlags(byte num) {
       this.num = num;
    }
    public byte getFlags(){
        return this.num;
    }
}
