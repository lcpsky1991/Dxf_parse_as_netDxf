package com.lcp.dxf.entities;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public class Polyline extends DxfObject implements IPolyline {
    private EntityType TYPE = EntityType.Polyline;

    @JsonProperty(value = "Vertexes")
    private List<PolylineVertex> vertexes;

    @JsonProperty(value = "IsClosed")
    private boolean isClosed;

    @JsonProperty(value = "Elevation")
    private float elevation;

    @JsonProperty(value = "Flags")
    private String flags;

    @JsonProperty(value = "Thickness")
    private float thickness;

    @JsonProperty(value = "Color")
    private AciColor color;

    @JsonProperty(value = "Layer")
    private Layer layer;

    @JsonProperty(value = "LineType")
    private LineType lineType;

    @JsonProperty(value = "Normal")
    private Vector3f normal;

    @JsonProperty(value = "CodeName")
    private String codeName;

    @JsonProperty(value = "Type")
    private String type;

    public String getCodeName() {
        return codeName;
    }

    public DxfObject setCodeName(String codeName) {
        this.codeName = codeName;
        return this;
    }

    public void setFlags(String flags) {
        this.flags = flags;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean getIsClosed() {
        return isClosed;
    }

    public void setIsClosed(boolean isClosed) {
        this.isClosed = isClosed;
    }

    public Layer getLayer() {
        return layer;
    }

    public void setLayer(Layer layer) {
        this.layer = layer;
    }

    public AciColor getColor() {
        return color;
    }

    public void setColor(AciColor color) {
        this.color = color;
    }

    public LineType getLineType() {
        return lineType;
    }

    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }

    public Vector3f getNormal() {
        return normal;
    }

    public void setNormal(Vector3f normal) throws Exception {
        if (new Vector3f(0, 0, 0) == normal)
            throw new Exception("The normal can not be the zero vector");
        normal.Normalize();
        this.normal = normal;
    }

    public float getElevation() {
        return elevation;
    }

    public void setElevation(float elevation) {
        this.elevation = elevation;
    }

    public float getThickness() {
        return thickness;
    }

    public void setThickness(float thickness) {
        this.thickness = thickness;
    }

    @Override
    public String getType() {
        // TODO Auto-generated method stub
        return this.TYPE.value();
    }

    public List<PolylineVertex> getVertexes() {
        return vertexes;
    }

    public void setVertexes(List<PolylineVertex> vertexes) throws Exception {
        if (vertexes == null)
            throw new Exception("value");
        this.vertexes = vertexes;
    }

    public void setFlags(PolylineTypeFlags flags) {
        this.flags = String.valueOf(flags.getNum());
    }

    public String getFlags() {
        // TODO Auto-generated method stub
        return this.flags;
    }

    public Polyline()

    {
        this.codeName = DxfObjectCode.Polyline;
        this.vertexes = new ArrayList<PolylineVertex>();
        this.isClosed = false;
        this.layer = new Layer("0");
        this.color = new AciColor((short) 256);
        this.lineType = new LineType("ByLayer");
        this.normal = new Vector3f(0, 0, 1);
        this.elevation = 0.0f;
        this.flags = PolylineTypeFlags.OpenPolyline.getNum();
    }

    public Polyline(List<PolylineVertex> polyVertexes, boolean isClosed) {
        // TODO Auto-generated constructor stub
        this.isClosed = isClosed;
        this.layer = new Layer("0");
        this.color = new AciColor((short) 256);
        this.lineType = new LineType("ByLayer");
        this.normal = new Vector3f(0, 0, 1);
        this.elevation = 0.0f;
        this.thickness = 0.0f;
        this.flags = isClosed ? PolylineTypeFlags.ClosedPolylineOrClosedPolygonMeshInM.getNum()
                : PolylineTypeFlags.OpenPolyline.getNum();
    }

    @Override
    public String toString() {
        return "Polyline [TYPE=" + TYPE + ", vertexes=" + vertexes + ", isClosed=" + isClosed + ", layer="
                + layer + ", color=" + color + ", lineType=" + lineType + ", normal=" + normal
                + ", elevation=" + elevation + ", thickness=" + thickness + ", flags=" + flags
                + ", codeName=" + codeName + ", handle=" + handle + "]";
    }

}
