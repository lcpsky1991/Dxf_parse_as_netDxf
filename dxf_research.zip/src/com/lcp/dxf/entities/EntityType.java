package com.lcp.dxf.entities;

enum EntityType
{  
    Line(0),
    Polyline(1),
    Polyline3d(2),
    LightWeightPolyline(3),
    PolyfaceMesh(4),
    Circle(5),
    NurbsCurve(6),
    Ellipse(7),
    Point(8),
    Arc(9),
    Text(10),
    Face3D(11),
    Solid(12),

    Insert(13),

    Hatch(14),

    Attribute(15),

    AttributeDefinition(16),

    LightWeightPolylineVertex(17),

    PolylineVertex(18),

    Polyline3dVertex(19),

    PolyfaceMeshVertex(20),

    PolyfaceMeshFace(21),

    Dimension(22),

    Vertex(23);
	
    
	private int value;

	private EntityType(){}
    
	private EntityType(int value){
    	this.value = value;
    }
  
    public String value(){
    	return this.value+"";
    }
    public static EntityType valueOf(int value){
    	switch (value) {
		case 0:
			return Line;
		case 1:
			return  Polyline;
		case 3:
			return LightWeightPolyline;
		case 5:
			return Circle;
		case 8:
			return Point;
		case 9:
			return Arc;
		case 10:
			return Text;
		default:
			break;
		}
		return null;
    }
}