package com.lcp.dxf.entities;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public interface IEntityObject {
    /// <summary>
    /// Gets the entity <see cref="EntityType">type</see>.
    /// </summary>
	
    String getType();
    
    /// <summary>
    /// Gets or sets the entity <see cref="AciColor">color</see>.
    /// </summary>
    AciColor getColor();
    void setColor(AciColor color);

    /// <summary>
    /// Gets or sets the entity <see cref="Layer">layer</see>.
    /// </summary>
    Layer getLayer();
    void setLayer(Layer layer);

    /// <summary>
    /// Gets or sets the entity <see cref="LineType">line type</see.
    /// </summary>
    LineType getLineType();
    void setLineType(LineType lineType);
    /// <summary>
    /// Gets or sets the entity <see cref="XData">extended data</see.
    /// </summary>
 
}
