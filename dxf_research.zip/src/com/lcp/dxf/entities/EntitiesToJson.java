package com.lcp.dxf.entities;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

public class EntitiesToJson implements Serializable{
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	 
    public List<Arc> arcs;
        
    public List<Circle> circles;
      
    public List<Ellipse> ellipses;
 

    private List<Line> lines;

    private List<Point> points;

    private List<IPolyline> polylines;

    private List<Text> texts;
   
    private List<MText> mtexts;
    private double Xmin;
    private double Xmax;
    private double Ymin;
    private double Ymax;

    public List<Arc> getArcs() {
        return arcs;
    }

    public void setArcs(List<Arc> arcs) {
        this.arcs = arcs;
    }

    public List<Circle> getCircles() {
        return circles;
    }

    public void setCircles(List<Circle> circles) {
        this.circles = circles;
    }

    public List<Ellipse> getEllipses() {
        return ellipses;
    }

    public void setEllipses(List<Ellipse> ellipses) {
        this.ellipses = ellipses;
    }

    public List<Line> getLines() {
        return lines;
    }

    public void setLines(List<Line> lines) {
        this.lines = lines;
    }

    public List<Point> getPoints() {
        return points;
    }

    public void setPoints(List<Point> points) {
        this.points = points;
    }

    public List<IPolyline> getPolylines() {
        return polylines;
    }

    public void setPolylines(List<IPolyline> polylines) {
        this.polylines = polylines;
    }

    public List<Text> getTexts() {
        return texts;
    }

    public void setTexts(List<Text> texts) {
        this.texts = texts;
    }

    public List<MText> getMtexts() {
        return mtexts;
    }

    public void setMtexts(List<MText> mtexts) {
        this.mtexts = mtexts;
    }


	public double getXmin() {
        return Xmin;
    }

    public void setXmin(double xmin) {
        Xmin = xmin;
    }

    public double getXmax() {
        return Xmax;
    }

    public void setXmax(double xmax) {
        Xmax = xmax;
    }

    public double getYmin() {
        return Ymin;
    }

    public void setYmin(double ymin) {
        Ymin = ymin;
    }

    public double getYmax() {
        return Ymax;
    }

    public void setYmax(double ymax) {
        Ymax = ymax;
    }

    @Override
	public String toString() {
		return "EntitiesToJson [arcs=" + arcs + ", circles=" + circles + ", ellipses=" + ellipses + ", lines=" + lines
				+ ", points=" + points + ", polylines=" + polylines + ", texts=" + texts + ", mtexts=" + mtexts
				+ ", Xmin=" + Xmin + ", Xmax=" + Xmax + ", Ymin=" + Ymin + ", Ymax=" + Ymax + "]";
	}
    
}
