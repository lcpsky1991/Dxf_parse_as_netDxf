package com.lcp.dxf.entities;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.Vector3f;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;

public class Vertex extends DxfObject {
    private VertexTypeFlags flags;
    @JsonProperty(value = "Location")  
    private Vector3f location;
    private int[] vertexIndexes;
    @JsonProperty(value = "BeginThickness")  
    private float beginThickness;
    @JsonProperty(value = "EndThickness")  
    private float endThickness;
    @JsonProperty(value = "Bulge")  
    private float bulge;
    private AciColor color;
    private Layer layer;
    private LineType lineType;
    public VertexTypeFlags getFlags() {
        return flags;
    }
    public void setFlags(VertexTypeFlags flags) {
        this.flags = flags;
    }
    public Vector3f getLocation() {
        return location;
    }
    public void setLocation(Vector3f location) {
        this.location = location;
    }
    public int[] getVertexIndexes() {
        return vertexIndexes;
    }
    public void setVertexIndexes(int[] vertexIndexes) {
        this.vertexIndexes = vertexIndexes;
    }
    public float getBeginThickness() {
        return beginThickness;
    }
    public void setBeginThickness(float beginThickness) {
        this.beginThickness = beginThickness;
    }
    public float getEndThickness() {
        return endThickness;
    }
    public void setEndThickness(float endThickness) {
        this.endThickness = endThickness;
    }
    public float getBulge() {
        return bulge;
    }
    public void setBulge(float bulge) throws Exception {
        if (this.bulge < 0.0f || this.bulge > 1.0f)
        {
            throw new Exception("The bulge must be a value between zero and one");
        }
        this.bulge = bulge;
    }
    public AciColor getColor() {
        return color;
    }
    public void setColor(AciColor color) {
        this.color = color;
    }
    public Layer getLayer() {
        return layer;
    }
    public void setLayer(Layer layer) {
        this.layer = layer;
    }
    public LineType getLineType() {
        return lineType;
    }
    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }
    public  String toString()
    {
        return this.codeName;
    }
}
