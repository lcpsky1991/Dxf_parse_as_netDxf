﻿package com.lcp.dxf.op;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.log4j.Logger;

import com.lcp.dxf.base.DxfDocument;
import com.lcp.dxf.utils.JsonUtils;

public class DxfTest {
	private static Logger logger = Logger.getLogger(DxfTest.class);
	public static void main(String[] args) {
	    logger.debug("parse begin");
		DxfDocument dxf = new DxfDocument();
		dxf.load("C:\\Users\\lcpsky\\workspace\\dxf_research\\dat\\source.dxf");		
        String json = JsonUtils.objectToJson(dxf.etj);
        File file = new File("D://data.txt");
        try {
			FileWriter fw = new FileWriter(file);
			fw.write(json);
			logger.debug("parse stop");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	}
}
