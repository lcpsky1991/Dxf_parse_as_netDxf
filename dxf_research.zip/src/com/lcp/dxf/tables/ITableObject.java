package com.lcp.dxf.tables;

public interface ITableObject {
   String getName();
}
