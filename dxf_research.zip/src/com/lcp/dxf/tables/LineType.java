package com.lcp.dxf.tables;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;

public class LineType extends DxfObject implements ITableObject {
    @JsonProperty(value="Name")
    private String name;
    @JsonProperty(value="Description")
    private String description;
    @JsonProperty(value="Segments")
    private List<Float> segments;
    public static final LineType ByLayer = new LineType("ByLayer");
    public static final LineType ByBlock = new LineType("ByBlock");
    public static final LineType Continuous = new LineType("Continuous").setDescription("Solid line");
    public static final LineType Center = new LineType("Center").setDescription("Center, ____ _ ____ _ ____ _ ____ _ ____ _ ____");
    public static final LineType Dashed = new LineType("Center").setDescription("Dashed, __ __ __ __ __ __ __ __ __ __ __ __ __ _");
    public String getDescription() {
        return description;
    }

    public LineType setDescription(String description) {
        this.description = description;
        return this;
    }

    public List<Float> getSegments() {
        return segments;
    }

    public LineType setSegments(List<Float> segments) {
        this.segments = segments;
        return this;
    }

    public LineType setName(String name) {
        this.name = name;
        return this;
    }


    public LineType(String name){
        this.codeName=DxfObjectCode.LineType;
        this.name=name;
        this.description = "";
        this.segments = new ArrayList<Float>();
    }

    public LineType(){
        // TODO Auto-generated constructor stub
    	this.name="ByLayer";
        this.codeName = DxfObjectCode.LineType;
        this.description = "";
        this.segments = new ArrayList<Float>();
    }

    @Override
    public String getName() {
        // TODO Auto-generated method stub
        return this.name;
    }

    @Override
    public String toString() {
        return "LineType [name=" + name + ", description=" + description + ", segments=" + segments + "]";
    }
    
}
