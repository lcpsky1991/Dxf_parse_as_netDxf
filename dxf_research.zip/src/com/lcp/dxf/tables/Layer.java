package com.lcp.dxf.tables;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.AciColor;
import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;

public class Layer extends DxfObject implements ITableObject{
    @JsonProperty(value="PlotStyleHandle")
    private static String plotStyleHandle;
    @JsonProperty(value="Name")
    private String name;
    @JsonProperty(value="Color")
    private AciColor color;
    @JsonProperty(value="IsVisible")
    private boolean isVisible;
    @JsonProperty(value="LineType")
    private LineType lineType;
    
    public static String getPlotStyleHandle() {
        return plotStyleHandle;
    }

    public static void setPlotStyleHandle(String plotStyleHandle) {
        Layer.plotStyleHandle = plotStyleHandle;
    }

    public String getName() {
        return name;
    }

    public Layer setName(String name) {
        this.name = name;
        return this;
    }

    public AciColor getColor() {
        return color;
    }

    public void setColor(AciColor color) {
        this.color = color;
    }

    public boolean getIsVisible() {
        return isVisible;
    }

    public void setIsVisible(boolean isVisible) {
        this.isVisible = isVisible;
    }

    public LineType getLineType() {
        return lineType;
    }

    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }

    public Layer(String name) {
        this.codeName=DxfObjectCode.Layer;
        if (null==name)
            throw new NullPointerException(name);
        this.name = name;
        this.color = new AciColor((short)7);
        this.lineType = LineType.Continuous;
        this.isVisible = true;
    }

    public Layer() {
        // TODO Auto-generated constructor stub
        this.codeName=DxfObjectCode.Layer;
        // TODO Auto-generated constructor stub
        this.color = new AciColor((short)7);
        this.lineType = new LineType();
        this.isVisible = true;
    }

    @Override
    public String toString() {
        return "Layer [name=" + name + ", color=" + color + ", isVisible=" + isVisible + ", lineType="
                + lineType + "]";
    }
     
}
