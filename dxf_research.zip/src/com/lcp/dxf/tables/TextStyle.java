package com.lcp.dxf.tables;

import org.codehaus.jackson.annotate.JsonProperty;

import com.lcp.dxf.base.DxfObject;
import com.lcp.dxf.base.DxfObjectCode;

public class TextStyle extends DxfObject implements ITableObject{
    
    @JsonProperty(value="Font")
    private String font;
    
    @JsonProperty(value="Name")
    private String name;
    @JsonProperty(value="Heigth")
    private float height;
    @JsonProperty(value="IsBackWard")
    private boolean isBackward;
    @JsonProperty(value="IsUpsideDown")
    private boolean isUpsideDown;
    @JsonProperty(value="IsVertical")
    private boolean isVertical;
    @JsonProperty(value="ObliqueAngle")
    private float obliqueAngle;
    @JsonProperty(value="WidthFactor")
    private float widthFactor;
    
    public static final TextStyle Default = new TextStyle("Standard", "simplex");
    public TextStyle(String codeName) {
        super(codeName);
        // TODO Auto-generated constructor stub
    }

    @Override
    public String getName() {
        // TODO Auto-generated method stub
        return this.name;
    }
    public TextStyle(String name, String font){
        this.codeName = DxfObjectCode.TextStyle;
        this.name = name;
        if (null==font||font.equals(""))
            font = "simplex";
        this.font = font;
        this.widthFactor = 1.0f;
        this.obliqueAngle = 0.0f;
        this.height = 0.0f;
        this.isVertical = false;
        this.isBackward = false;
        this.isUpsideDown = false;
    }

    public String getFont() {
        return font;
    }

    public void setFont(String font) {
        this.font = font;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public boolean getIsBackward() {
        return isBackward;
    }

    public void setIsBackward(boolean isBackward) {
        this.isBackward = isBackward;
    }

    public boolean getIsUpsideDown() {
        return isUpsideDown;
    }

    public void setIsUpsideDown(boolean isUpsideDown) {
        this.isUpsideDown = isUpsideDown;
    }

    public boolean getIsVertical() {
        return isVertical;
    }

    public void setIsVertical(boolean isVertical) {
        this.isVertical = isVertical;
    }

    public float getObliqueAngle() {
        return obliqueAngle;
    }

    public void setObliqueAngle(float obliqueAngle) {
        this.obliqueAngle = obliqueAngle;
    }

    public float getWidthFactor() {
        return widthFactor;
    }

    public void setWidthFactor(float widthFactor) {
        this.widthFactor = widthFactor;
    }

    public void setName(String name) {
        this.name = name;
    }

	@Override
	public String toString() {
		return "TextStyle [font=" + font + ", name=" + name + "]";
	}


    
}
