package com.lcp.dxf.base;

import org.codehaus.jackson.annotate.JsonProperty;

public class Vector2f {
    @JsonProperty(value = "X")  
    private double x;
    @JsonProperty(value = "Y")  
    private double y;
   
    
    public Vector2f(double x, double y)
    {
        this.x = x;
        this.y = y;
     
    }
    
    public Vector2f(double[] array) throws Exception
    {
        if (array.length != 2)
            throw new Exception("The dimension of the array must be two.");
        this.x = array[0];
        this.y = array[1];
    }
    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

	@Override
	public String toString() {
		return "Location [x=" + x + ", y=" + y + "]";
	}

   
    
    
}
