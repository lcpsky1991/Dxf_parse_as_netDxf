package com.lcp.dxf.base;

import org.codehaus.jackson.annotate.JsonProperty;

public class Vector3f {
    @JsonProperty(value = "X")  
    private double x;
    @JsonProperty(value = "Y")  
    private double y;
    @JsonProperty(value = "Z")  
    private double z;
    
    public Vector3f(double x, double y, double z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public Vector3f(double[] array) throws Exception
    {
        if (array.length != 3)
            throw new Exception("The dimension of the array must be three.");
        this.x = array[0];
        this.y = array[1];
        this.z = array[2];
    }
    public double getX() {
        return x;
    }

    public Vector3f setX(double x) {
        this.x = x;
        return this;
    }

    public double getY() {
        return y;
    }

    public Vector3f setY(double y) {
        this.y = y;
        return this;
    }

    public double getZ() {
        return z;
    }

    public Vector3f setZ(double z) {
        this.z = z;
        return this;
    }
    
    public void Normalize()
    {
        double mod = this.Modulus();
        if (mod == 0)
            throw new ArithmeticException("Cannot normalize a zero vector.");
        double modInv = 1 / mod;
        this.x *= modInv;
        this.y *= modInv;
        this.z *= modInv;
    } 
    public double Modulus()
    {
        return (double)Math.sqrt(DotProduct(this, this));
    }
    public static double DotProduct(Vector3f u, Vector3f v)
    {
        return (u.x * v.x) + (u.y * v.y) + (u.z * v.z);
    }

    @Override
    public String toString() {
        return "Vector3f [x=" + x + ", y=" + y + ", z=" + z + "]";
    }
    
}
