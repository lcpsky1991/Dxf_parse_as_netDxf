package com.lcp.dxf.base;

import org.codehaus.jackson.annotate.JsonProperty;

public class DxfObject {
    @JsonProperty(value = "CodeName")  
    protected String codeName;
    @JsonProperty(value = "Handle")  
    protected String handle;


    /// <summary>
    /// Initializes a new instance of the <c>DxfObject</c> class.
    /// </summary>
    public DxfObject(String codeName)
    {
        this.codeName = codeName;
    }



    /// <summary>
    /// Gets the dxf entity type String.
    /// </summary>
    
    public String CodeName()
    {
       return this.codeName;
    }

    /// <summary>
    /// Gets or sets the handle asigned of the dxf object.
    /// </summary>
    /// <remarks>Only the getter is public.</remarks>
    
   
    


    public DxfObject setCodeName(String codeName) {
        this.codeName = codeName;
        return this;
    }



    public DxfObject() {
        super();
        // TODO Auto-generated constructor stub
    }



    public String getHandle() {
        return handle;
    }



    public void setHandle(String handle) {
        this.handle = handle;
    }

   

    /// <summary>
    /// Asigns a handle to the object based in a integer counter.
    /// </summary>
    /// <param name="entityNumber">Number to asign.</param>
    /// <returns>Next avaliable entity number.</returns>
    /// <remarks>
    /// Some objects might consume more than one, is, for example, the case of polylines that will asign
    /// automatically a handle to its vertexes. The entity number will be converted to an hexadecimal number.
    /// </remarks>
    public int AsignHandle(int entityNumber)
    {
        this.handle = Integer.toHexString(entityNumber).toString();
        return entityNumber + 1;
    }

}
