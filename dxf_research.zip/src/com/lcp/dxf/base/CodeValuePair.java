package com.lcp.dxf.base;

public class CodeValuePair {
    private  int code;
    private  String value;
    
    public CodeValuePair(int code, String value)
    {
        this.code = code;
        this.value = value;
    }
    
    
    public int getCode() {
        return code;
    }
  
    public String getValue() {
        return value;
    }
 
    
}
