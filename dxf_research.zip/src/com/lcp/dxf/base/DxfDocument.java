package com.lcp.dxf.base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.lcp.dxf.entities.Arc;
import com.lcp.dxf.entities.Circle;
import com.lcp.dxf.entities.Ellipse;
import com.lcp.dxf.entities.EntitiesToJson;
import com.lcp.dxf.entities.IPolyline;
import com.lcp.dxf.entities.LwPolylineVertex;
import com.lcp.dxf.entities.Polyline;
import com.lcp.dxf.entities.Line;
import com.lcp.dxf.entities.LwPolyLine;
import com.lcp.dxf.entities.MText;
import com.lcp.dxf.entities.Point;
import com.lcp.dxf.entities.Solid;
import com.lcp.dxf.entities.Text;
import com.lcp.dxf.tables.Layer;
import com.lcp.dxf.tables.LineType;
import com.lcp.dxf.tables.TextStyle;

public class DxfDocument {
    private static Logger logger = Logger.getLogger(DxfDocument.class);
	private String fileName;

	private String version;

	private int handleCount = 100;

	private List<Arc> arcs;

	private List<Circle> circles;

	private List<Ellipse> ellipses;

	private List<Solid> solids;

	private List<Line> lines;

	private List<Point> points;

	private List<IPolyline> polylines;

	private List<Text> texts;

	private HashMap<String, Layer> layers;

	private HashMap<String, LineType> lineTypes;

	private HashMap<String, TextStyle> textStyles;

	public HashMap<String, Layer> getLayers() {
		return layers;
	}

	public void setLayers(HashMap<String, Layer> layers) {
		this.layers = layers;
	}

	public HashMap<String, LineType> getLineTypes() {
		return lineTypes;
	}

	public void setLineTypes(HashMap<String, LineType> lineTypes) {
		this.lineTypes = lineTypes;
	}

	public HashMap<String, TextStyle> getTextStyles() {
		return textStyles;
	}

	public void setTextStyles(HashMap<String, TextStyle> textStyles) {
		this.textStyles = textStyles;
	}

	private List<MText> mtexts;

	public EntitiesToJson etj;

	private BufferedReader br;
	private double Xmin = Integer.MAX_VALUE;
	private double Xmax = 0;
	private double Ymin = Integer.MAX_VALUE;
	private double Ymax = 0;

	private String[] str = new String[2];

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getHandleCount() {
		return handleCount;
	}

	public void setHandleCount(int handleCount) {
		this.handleCount = handleCount;
	}

	public List<Arc> getArcs() {
		return arcs;
	}

	public void setArcs(List<Arc> arcs) {
		this.arcs = arcs;
	}

	public List<Circle> getCircles() {
		return circles;
	}

	public void setCircles(List<Circle> circles) {
		this.circles = circles;
	}

	public List<Ellipse> getEllipses() {
		return ellipses;
	}

	public void setEllipses(List<Ellipse> ellipses) {
		this.ellipses = ellipses;
	}

	public List<Solid> getSolids() {
		return solids;
	}

	public void setSolids(List<Solid> solids) {
		this.solids = solids;
	}

	public List<Line> getLines() {
		return lines;
	}

	public void setLines(List<Line> lines) {
		this.lines = lines;
	}

	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}

	public List<IPolyline> getPolylines() {
		return polylines;
	}

	public void setPolylines(List<IPolyline> polylines) {
		this.polylines = polylines;
	}

	public List<Text> getTexts() {
		return texts;
	}

	public void setTexts(List<Text> texts) {
		this.texts = texts;
	}

	public List<MText> getMtexts() {
		return mtexts;
	}

	public void setMtexts(List<MText> mtexts) {
		this.mtexts = mtexts;
	}

	public EntitiesToJson getEtj() {
		return etj;
	}

	public void setEtj(EntitiesToJson etj) {
		this.etj = etj;
	}

	public DxfDocument() {
		logger.debug("DxfDocument initial");
		this.layers = new HashMap<String, Layer>();
		this.lineTypes = new HashMap<String, LineType>();
		this.textStyles = new HashMap<String, TextStyle>();
		this.arcs = new ArrayList<Arc>();
		this.ellipses = new ArrayList<Ellipse>();
		this.solids = new ArrayList<Solid>();
		this.polylines = new ArrayList<IPolyline>();
		this.lines = new ArrayList<Line>();
		this.circles = new ArrayList<Circle>();
		this.points = new ArrayList<Point>();
		this.texts = new ArrayList<Text>();
		this.mtexts = new ArrayList<MText>();
		this.etj = new EntitiesToJson();
	}

	public void load(String file) {
		try {
			logger.debug("DxfDocument loading");
			File f = new File(file);
			FileInputStream fis = new FileInputStream(f);
			InputStreamReader isr = new InputStreamReader(fis, "utf-8");
			br = new BufferedReader(isr);
			logger.debug("DxfDocument read start...");
			Read();
			logger.debug("DxfDocument read stop...");
			br.close();
			isr.close();
			fis.close();
		} catch (Exception e) {
			System.out.println("help");
			e.printStackTrace();
		} finally {
			etj.setArcs(arcs);
			etj.setCircles(circles);
			etj.setEllipses(ellipses);
			etj.setPoints(points);
			etj.setPolylines(polylines);
			etj.setLines(lines);
			etj.setTexts(texts);
			etj.setMtexts(mtexts);
			etj.setXmax(Xmax);
			etj.setXmin(Xmin);
			etj.setYmax(Ymax);
			etj.setYmin(Ymin);

		}

	}

	public String[] ReadPair() {
		String[] result = null;
		try {
			String code = br.readLine();
			String codedata = br.readLine();

			result = new String[] { code.trim(), codedata.trim() };

		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	public void Read() {
		try {
			
			String temp = br.readLine();
			while (temp != null) {
				String code = temp;
				String codedata = br.readLine();
				str = new String[] { code.trim(), codedata.trim() };
				if (str[1].equals("HEADER"))
				{
					ReadHeader();
				// if (str[1].equals("TABLES")) {
				// System.out.println("TABLES");
				// ReadTable();
				// }
					
				}
				if (str[1].equals("ENTITIES")) {
					// System.out.println("ENTITIES");
					ReadEntities();
				}
				temp = br.readLine();
			}
		} catch (IOException e) {
			System.out.println("help1");
			e.printStackTrace();
		}

	}

	public void ReadEntities() {
		try {
			while (!str[1].equals("ENDSEC")) {
				if (str[1].equals("LINE")) {
					// System.out.println("Line");
					ReadLine();
				} else if (str[1].equals("ARC"))
					ReadArc();
				else if (str[1].equals("CIRCLE")) {
					// System.out.println("circle");
					ReadCircle();
				} else if (str[1].equals("POINT")) {
					ReadPoint();
				} 
//				else if (str[1].equals("POLYLINE"))
//					ReadPolyline();
				// else if (str[1].equals("ELLIPSE")) ReadEllipse();
				else if (str[1].equals("LWPOLYLINE")) {
					// System.out.println("aaaa");
					ReadLwpolyline();
				} else if (str[1].equals("TEXT")) {
					ReadText();
				} else if (str[1].equals("MTEXT")) {
					ReadMText();
				} else
					str = ReadPair();
			}
		} catch (Exception e) {
			System.out.println("help2");
			e.printStackTrace();
		}

	}

	public List<Text> ReadText() {
		Text newText = new Text();
		while (!str[1].equals("ENDSEC")) {
			str = ReadPair();
			if (str[0].equals("5")) {
				newText.handle = str[1];
				continue;
			}
			if (str[0].equals("8"))
				try {
					newText.setLayer(newText.getLayer().setName(new String(str[1].getBytes("utf-8"), "utf-8")));
					continue;
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if (str[0].equals("10")) {
				newText.setBasePoint(newText.getBasePoint().setX(Float.valueOf(str[1])));
				if (newText.getBasePoint().getX() > Xmax)
					Xmax = newText.getBasePoint().getX();
				if (newText.getBasePoint().getX() < Xmin)
					Xmin = newText.getBasePoint().getX();
				continue;
			}
			if (str[0].equals("20")) {
				newText.setBasePoint(newText.getBasePoint().setY(Float.valueOf(str[1])));
				if (newText.getBasePoint().getY() > Ymax)
					Ymax = newText.getBasePoint().getY();
				if (newText.getBasePoint().getY() < Ymin)
					Ymin = newText.getBasePoint().getY();
				continue;
			}
			if (str[0].equals("1")) {
				newText.setValue(str[1]);
				continue;
			}
			if (str[0].equals("62")) {
				newText.setColor(new AciColor(Short.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("40")) {
				newText.setHeight(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("41")) {
				newText.setWidthFactor(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("50")) {
				newText.setRotation(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("51")) {
				newText.setObliqueAngle(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("210")) {
				{
					newText.setNormal(newText.getNormal().setX(Float.valueOf(str[1])));
					continue;
				}
			}
			if (str[0].equals("220")) {
				newText.setNormal(newText.getNormal().setY(Float.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("230")) {
				newText.setNormal(newText.getNormal().setZ(Float.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("0")) {
				texts.add(newText);
				break;
			}
		}
		return texts;
	}

	private List<IPolyline> ReadPolyline(){
		Polyline newpolyLine = new Polyline();
		while (!str[1].equals("ENDSEC")) {
			str = ReadPair();
			if (str[0].equals("8")) {
				newpolyLine.getLayer().setName(new String(str[1]));
				continue;
			}

			if (str[0].equals("370")) {
				newpolyLine.setThickness(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("62")) {
				newpolyLine.setColor(new AciColor(Short.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("70"))
				newpolyLine.setFlags(str[1].trim());
			while (str[0].equals("10")) {
				Float px = Float.valueOf(str[1]);
				str = ReadPair();
				Float py = Float.valueOf(str[1]);
				try {
					newpolyLine.setNormal(new Vector3f(px, py, 0));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				str = ReadPair();
				if (str[0].equals("0")) {
					polylines.add(newpolyLine);
					break;
				}
			}
		}
		return polylines;

	}

	public List<IPolyline> ReadLwpolyline() throws UnsupportedEncodingException{
		LwPolyLine newlw = new LwPolyLine();
		LwPolylineVertex v = new LwPolylineVertex();
		float constantWidth = 0.0f;
		double vX = 0.0;
		ArrayList<LwPolylineVertex> list = new ArrayList<LwPolylineVertex>();
		while (!str[1].equals("ENDSEC")) {
			str = ReadPair();
			if (str[0].equals("5")) {
				newlw.handle = str[1];
				continue;
			}
			if (str[0].equals("8")) {
				newlw.setLayer(newlw.getLayer().setName(new String(str[1])));
				continue;
			}

			if (str[0].equals("370")) {
				newlw.setThickness(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("62")) {
				newlw.setColor(new AciColor(Short.valueOf(str[1].trim())));
				continue;
			}
			if (str[0].equals("90")) {
				str = this.ReadPair();
				continue;
			}
			if (str[0].equals("70")) {
				if (Integer.parseInt(str[1].trim()) == 1) {
					newlw.setIsClosed(true);
				} else if (Integer.parseInt(str[1].trim()) == 0) {
					newlw.setIsClosed(false);
				} 
				continue;
			}

			if (str[0].equals("43")) {
				constantWidth = Float.valueOf(str[1]);
				continue;
			}
			if (str[0].equals("210")) {
				newlw.setNormal(newlw.getNormal().setX(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("220")) {
				newlw.setNormal(newlw.getNormal().setY(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("230")) {
				newlw.setNormal(newlw.getNormal().setZ(Double.valueOf(str[1])));
				continue;
			}
			while (str[0].equals("10") || (str[0].equals("20"))) {
				if (str[0].equals("10")) {
					v = new LwPolylineVertex();
					v.setBeginThickness(constantWidth);
					v.setEndThickness(constantWidth);
					vX = Double.valueOf(str[1]);
					str = ReadPair();
				}
				if (str[0].equals("20")) {
					double vY = Float.valueOf(str[1]);
					v.setLocation(new Vector2f(vX, vY));
					if (v.getLocation().getX() > Xmax)
						Xmax = v.getLocation().getX();
					if (v.getLocation().getX() < Xmin)
						Xmin = v.getLocation().getX();
					if (v.getLocation().getY() > Ymax)
						Ymax = v.getLocation().getY();
					if (v.getLocation().getY() < Ymin) {
						Ymin = v.getLocation().getY();
					}
					list = (ArrayList<LwPolylineVertex>) newlw.getVertexes();
					list.add(v);
					str = ReadPair();
					newlw.setVertexes(list);
				}
				// if (str[0].equals("40")) {
				// v.setBeginThickness(Float.valueOf(str[1]));
				// str = ReadPair();
				// }
				// if (str[0].equals("41")) {
				// v.setEndThickness(Float.valueOf(str[1]));
				// str = ReadPair();
				// }
				// if (str[0].equals("42")) {
				// v.setBulge(Float.valueOf(str[1]));
				// str = ReadPair();
				// }
			}
			if (str[0].equals("0")) {
				polylines.add((IPolyline) newlw);
				break;
			}

		}
		return polylines;
	}

	private List<Point> ReadPoint() {
		Point newPoint = new Point();

		while (!str[1].equals("ENDSEC")) {
			str = ReadPair();
			if (str[0].equals("8"))
				try {
					newPoint.setLayer(newPoint.getLayer().setName(new String(str[1].getBytes("utf-8"), "utf-8")));
					continue;
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if (str[0].equals("10")) {
				newPoint.setLocation(newPoint.getLocation().setX(Double.valueOf(str[1])));
				if (newPoint.getLocation().getX() > Xmax)
					Xmax = newPoint.getLocation().getX();
				if (newPoint.getLocation().getX() < Xmin)
					Xmin = newPoint.getLocation().getX();
				continue;
			}
			if (str[0].equals("20")) {
				newPoint.setLocation(newPoint.getLocation().setY(Double.valueOf(str[1])));
				if (newPoint.getLocation().getY() > Ymax)
					Ymax = newPoint.getLocation().getY();
				if (newPoint.getLocation().getY() < Ymin)
					Ymin = newPoint.getLocation().getY();
				continue;
			}
			if (str[0].equals("30")) {
				newPoint.setLocation(newPoint.getLocation().setZ(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("62")) {
				newPoint.setColor(new AciColor(Short.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("39")) {
				newPoint.setThickness(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("210")) {
				newPoint.setNormal(newPoint.getNormal().setX(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("220")) {
				newPoint.setNormal(newPoint.getNormal().setY(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("230")) {
				newPoint.setNormal(newPoint.getNormal().setZ(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("0")) {
				points.add(newPoint);
				break;
			}
		}
		return points;
	}

	private List<Circle> ReadCircle() {
		Circle newcircle = new Circle();
		while (!str[1].equals("ENDSEC")) {
			str = ReadPair();

			if (str[0].equals("5")) {
				newcircle.handle = str[1];
				continue;
			}
			if (str[0].equals("6")) {
				newcircle.setLineType(newcircle.getLineType().setName(str[1]));
				continue;
			}
			if (str[0].equals("8"))
				{
					newcircle.setLayer(
							(Layer) newcircle.getLayer().setName(new String(str[1])));
					continue;
				
				}
			if (str[0].equals("10")) {
				newcircle.setCenter(newcircle.getCenter().setX(Double.valueOf(str[1])));
				if (newcircle.getCenter().getX() > Xmax)
					Xmax = newcircle.getCenter().getX();
				if (newcircle.getCenter().getX() < Xmin)
					Xmin = newcircle.getCenter().getX();
				continue;
			}
			if (str[0].equals("20")) {
				newcircle.setCenter(newcircle.getCenter().setY(Double.valueOf(str[1])));
				if (newcircle.getCenter().getY() > Ymax)
					Ymax = newcircle.getCenter().getY();
				if (newcircle.getCenter().getY() < Ymin)
					Ymin = newcircle.getCenter().getY();
				continue;
			}
			if(str[0].equals("30")){
				newcircle.setCenter(newcircle.getCenter().setZ(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("40")) {
				newcircle.setRadius(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("39")) {
				newcircle.setThickness(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("62")) {
				newcircle.setColor(new AciColor(Short.valueOf(str[1].trim())));
				continue;
			}
			if (str[0].equals("210")) {
				newcircle.setNormal(newcircle.getNormal().setX(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("220")) {
				newcircle.setNormal(newcircle.getNormal().setY(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("230")) {
				newcircle.setNormal(newcircle.getNormal().setZ(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("0")) {
				circles.add(newcircle);
				break;
			}
		}
		return circles;
	}

	public List<Arc> ReadArc() {
		Arc newarc = new Arc();
		while (!str[1].equals("ENDSEC")) {
			str = ReadPair();
			if (str[0].equals("5")) {
				newarc.handle = str[1];
				continue;
			}
			if (str[0].equals("6")) {
				newarc.setLineType(newarc.getLineType().setName(str[1]));
				continue;
			}
			if (str[0].equals("8"))
				{
					newarc.setLayer(newarc.getLayer().setName(new String(str[1])));
					continue;
				
				}
			if (str[0].equals("10")) {
				newarc.setCenter(newarc.getCenter().setX(Double.valueOf(str[1])));
				if (newarc.getCenter().getX() > Xmax)
					Xmax = newarc.getCenter().getX();
				if (newarc.getCenter().getX() < Xmin)
					Xmin = newarc.getCenter().getX();
				continue;
			}
			if (str[0].equals("20")) {
				newarc.setCenter(newarc.getCenter().setY(Double.valueOf(str[1])));
				if (newarc.getCenter().getY() > Ymax)
					Ymax = newarc.getCenter().getY();
				if (newarc.getCenter().getY() < Ymin)
					Ymin = newarc.getCenter().getY();
				continue;
			}
			if(str[0].equals("30")){
				newarc.setCenter(newarc.getCenter().setZ(Double.valueOf(str[1])));
				continue;
			}
			if(str[0].equals("39")){
				newarc.setThickness(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("40")) {
				newarc.setRadius(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("50")) {
				newarc.setStartAngle(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("51")) {
				newarc.setEndAngle(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("62")) {
				newarc.setColor(new AciColor(Short.valueOf(str[1].trim())));
				continue;
			}
			if (str[0].equals("210")) {
				newarc.setNormal(newarc.getNormal().setX(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("220")) {
				newarc.setNormal(newarc.getNormal().setY(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("0")) {
				// System.out.println("circle");
				arcs.add(newarc);
				break;
			}

		}
		return arcs;

	}

	public List<Line> ReadLine() {
		Line newline = new Line();
		while (!str[1].equals("ENDSEC")) {
			str = ReadPair();
			if (str[0].equals("5")) {
				newline.handle = str[1];
				continue;
			}
			if (str[0].equals("6")) {
				newline.setLineType(newline.getLineType().setName(str[1]));
				continue;
			}
			if (str[0].equals("8")){
					newline.setLayer(newline.getLayer().setName(new String(str[1])));
					continue;}
			if (str[0].equals("10")) {
				newline.setStartPoint(newline.getStartPoint().setX(Double.valueOf(str[1])));
				if (Double.valueOf(str[1]) > Xmax) {
					Xmax = Double.valueOf(str[1]);
				}
				if (Double.valueOf(str[1]) < Xmin) {
					Xmin = Double.valueOf(str[1]);
				}
				continue;
			}
			if (str[0].equals("20")) {
				newline.setStartPoint(newline.getStartPoint().setY(Double.valueOf(str[1])));
				if (Double.valueOf(str[1]) > Ymax) {
					Ymax = Double.valueOf(str[1]);
				}
				if (Double.valueOf(str[1]) < Ymin) {
					Ymin = Double.valueOf(str[1]);
				}
				continue;
			}
			if (str[0].equals("11")) {
				newline.setEndPoint(newline.getEndPoint().setX(Double.valueOf(str[1])));
				if (Double.valueOf(str[1]) > Xmax) {
					Xmax = Double.valueOf(str[1]);
				}
				if (Double.valueOf(str[1]) < Xmin) {
					Xmin = Double.valueOf(str[1]);
				}
				continue;
			}
			if (str[0].equals("21")) {
				newline.setEndPoint(newline.getEndPoint().setY(Double.valueOf(str[1])));
				if (Double.valueOf(str[1]) > Ymax) {
					Ymax = Double.valueOf(str[1]);
				}
				if (Double.valueOf(str[1]) < Ymin) {
					Ymin = Double.valueOf(str[1]);
				}
				continue;
			}
			if (str[0].equals("62")) {
				newline.setColor(new AciColor(Short.valueOf(str[1].trim())));
				continue;
			}
			if (str[0].equals("39")) {
				newline.setThickness(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("0")) {
				{
					lines.add(newline);
					break;
				}
			}

		}
		return lines;

	}
	//
	// public void ReadTable() {
	// while (!str[1].equals("ENDSEC")) {
	//
	// while (!str[0].equals("2") || !str[1].equals("LAYER")) {
	//
	// str = ReadPair();
	// }
	// while (str[0].equals("2") && str[1].equals("LAYER")) {
	// // System.out.println("layer");
	// ReadLAYER();
	// }
	// while (!str[1].equals("ENDSEC")) {
	//
	// str = ReadPair();
	// }
	// }
	//
	// }
	//
	// public void ReadLAYER() {
	// try {
	// Layer newlayer = new Layer();
	// while (!str[1].equals("ENDTAB")) {
	// // System.out.println("LAYER");
	// str = ReadPair();
	// if (str[0].equals("2"))
	// newlayer.setName(new String(str[1].getBytes("utf-8"), "UTF-8"));
	// if (str[0].equals("62"))
	// newlayer.setColor(new AciColor(Short.valueOf(str[1].trim())));
	// if (str[0].equals("6"))
	// if (newlayer.getLineType() == null)
	// newlayer.setLineType(new LineType());
	// newlayer.getLineType().setName(str[1]);
	// if (str[0].equals("370"))
	// if (newlayer.getLineType() == null)
	// newlayer.setLineType(new LineType());
	// newlayer.getLineType().setDescription(str[1]);
	// if (str[0].equals("2") && str[1].equals("LAYER")) {
	// // System.out.println("LAYERLIST");
	// layers.put(newlayer.getName(), newlayer);
	// return;
	// }
	// }
	// // System.out.println("LAYERLIST");
	// } catch (Exception e) {
	// System.out.println("help3");
	// e.printStackTrace();
	// }
	//
	// }

	private void ReadHeader() {
		str = ReadPair();
		while (!str[1].equals("ENDSEC")) {
			if (str[1].equals("$ACADVER")) {
				str = ReadPair();
				this.version = str[1];
				continue;
			}
			if (str[1].equals("$EXTMIN")) {
				str = ReadPair();
				this.Xmin = Double.valueOf(str[1]);
				str = ReadPair();
				this.Ymin = Double.valueOf(str[1]);
				continue;
			}
			if (str[1].equals("$EXTMAX")) {
				str = ReadPair();
				this.Xmax = Double.valueOf(str[1]);
				str = ReadPair();
				this.Ymax = Double.valueOf(str[1]);
				continue;
			}
			str = ReadPair();
		}
	}

	private List<MText> ReadMText() {
		MText newText = new MText();
		while (!str[1].equals("ENDSEC")) {
			str = ReadPair();
			if (str[0].equals("5")) {
				newText.handle = str[1];
				continue;
			}
			if (str[0].equals("6")) {
				newText.setLineType(newText.getLineType().setName(str[1]));
				continue;
			}
			if (str[0].equals("1")) {
				newText.setValue(str[1]);
				continue;
			}
			if (str[0].equals("8"))
				{
					newText.setLayer(newText.getLayer().setName(new String(str[1])));
					continue;
				
				}
			if (str[0].equals("10")) {
				newText.setBasePoint(newText.getBasePoint().setX(Double.valueOf(str[1])));
				if (newText.getBasePoint().getX() > Xmax)
					Xmax = newText.getBasePoint().getX();
				if (newText.getBasePoint().getX() < Xmin)
					Xmin = newText.getBasePoint().getX();
				continue;
			}
			if (str[0].equals("20")) {
				newText.setBasePoint(newText.getBasePoint().setY(Double.valueOf(str[1])));
				if (newText.getBasePoint().getY() > Ymax)
					Ymax = newText.getBasePoint().getY();
				if (newText.getBasePoint().getY() < Ymin)
					Ymin = newText.getBasePoint().getY();
				continue;
			}
			if (str[0].equals("40")) {
				newText.setHeight(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("41")) {
				newText.setWidthFactor(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("50")) {
				newText.setRotation(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("51")) {
				newText.setObliqueAngle(Float.valueOf(str[1]));
				continue;
			}
			if (str[0].equals("62")) {
				newText.setColor(new AciColor(Short.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("210")) {
				newText.setNormal(newText.getNormal().setX(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("220")) {
				newText.setNormal(newText.getNormal().setY(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("230")) {
				newText.setNormal(newText.getNormal().setZ(Double.valueOf(str[1])));
				continue;
			}
			if (str[0].equals("0")) {
				mtexts.add(newText);
				break;
			}
		}
		return mtexts;
	}

	@Override
	public String toString() {
		return "DxfDocument [version=" + version + ", arcs=" + arcs + ", circles=" + circles + ", ellipses=" + ellipses
				+ ", solids=" + solids + ", lines=" + lines + ", points=" + points + ", polylines=" + polylines
				+ ", texts=" + texts + ", layers=" + layers + ", lineTypes=" + lineTypes + ", textStyles=" + textStyles
				+ ", mtexts=" + mtexts + ", Xmin=" + Xmin + ", Xmax=" + Xmax + ", Ymin=" + Ymin + ", Ymax=" + Ymax
				+ "]";
	}

}
