package com.lcp.dxf.base;

public class DxfObjectCode {
    /// <summary>
    /// application registry.
    /// </summary>
    public static String AppId = "APPID";

    /// <summary>
    /// dimension style.
    /// </summary>
    public static String DimStyle = "DIMSTYLE";

    /// <summary>
    /// block record.
    /// </summary>
    public static String BlockRecord = "BLOCK_RECORD";

    /// <summary>
    /// line type.
    /// </summary>
    public static String LineType = "LTYPE";

    /// <summary>
    /// layer.
    /// </summary>
    public static String Layer = "LAYER";

    /// <summary>
    /// viewport.
    /// </summary>
    public static String ViewPort = "VPORT";

    /// <summary>
    /// text style.
    /// </summary>
    public static String TextStyle = "STYLE";

    /// <summary>
    /// view.
    /// </summary>
    public static String View = "VIEW";

    /// <summary>
    /// ucs.
    /// </summary>
    public static String Ucs = "UCS";

    /// <summary>
    /// block.
    /// </summary>
    public static String Block = "BLOCK";

    /// <summary>
    /// block.
    /// </summary>
    public static String BlockEnd = "ENDBLK";

    /// <summary>
    /// line.
    /// </summary>
    public static String Line = "LINE";

    /// <summary>
    /// ellipse.
    /// </summary>
    public static String Ellipse = "ELLIPSE";

    /// <summary>
    /// polyline.
    /// </summary>
    public static String Polyline = "POLYLINE";

    /// <summary>
    /// light weight polyline.
    /// </summary>
    public static String LightWeightPolyline = "LWPOLYLINE";

    /// <summary>
    /// circle.
    /// </summary>
    public static String Circle = "CIRCLE";

    /// <summary>
    /// point.
    /// </summary>
    public static String Point = "POINT";

    /// <summary>
    /// arc.
    /// </summary>
    public static String Arc = "ARC";

    /// <summary>
    /// solid.
    /// </summary>
    public static String Solid = "SOLID";

    /// <summary>
    /// text String.
    /// </summary>
    public static String Text = "TEXT";

    /// <summary>
    /// Mtext String.
    /// </summary>
    public static String MText = "MTEXT";

    /// <summary>
    /// 3d face.
    /// </summary>
    public static String Face3D = "3DFACE";

    /// <summary>
    /// block insertion.
    /// </summary>
    public static String Insert = "INSERT";

    /// <summary>
    /// hatch.
    /// </summary>
    public static String Hatch = "HATCH";

    /// <summary>
    /// attribute definition.
    /// </summary>
    public static String AttributeDefinition = "ATTDEF";

    /// <summary>
    /// attribute.
    /// </summary>
    public static String Attribute = "ATTRIB";

    /// <summary>
    /// vertex.
    /// </summary>
    public static String Vertex = "VERTEX";

    /// <summary>
    /// end sequence.
    /// </summary>
    public static String EndSequence = "SEQEND";

    /// <summary>
    /// dim.
    /// </summary>
    public static String Dimension = "DIMENSION";

    /// <summary>
    /// dictionary.
    /// </summary>
    public static String Dictionary = "DICTIONARY";
}
