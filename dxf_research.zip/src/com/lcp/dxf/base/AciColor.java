package com.lcp.dxf.base;

import java.awt.Color;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.annotate.JsonProperty;

public class AciColor implements Serializable{
  //  public static final AciColor Default = new AciColor(7);

    private static Map<Short, int[]> aciColors = AciColors();
    @JsonProperty(value = "Index")  
    private short index;
    @JsonProperty(value = "R")  
    private short r;
    @JsonProperty(value = "G")  
    private short g;
    @JsonProperty(value = "B")  
    private short b;
    
    public static Map<Short, int[]> getAciColors() {
        return aciColors;
    }

    public static void setAciColors(Map<Short, int[]> aciColors) {
        AciColor.aciColors = aciColors;
    }

    public short getIndex() {
        return index;
    }

    public void setIndex(short index) throws Exception {
        if (index < 0 || index > 256)
        {
            throw new Exception();
        }
        this.index = index;
    }

    public short getR() {
        return r;
    }

    public void setR(short r) {
        this.r = r;
    }

    public short getG() {
        return g;
    }

    public void setG(short g) {
        this.g = g;
    }

    public short getB() {
        return b;
    }

    public void setB(short b) {
        this.b = b;
    }

//    public static AciColor getDefault() {
//        return Default;
//    }

    public static AciColor getAciColorByLayer()
    {
        return new AciColor((short)256); 
    }
   
    private static Map<Short, int[]> AciColors() {
        // TODO Auto-generated method stub
        Map colors = new HashMap<Short, int[]>();
        colors.put(Short.valueOf("0"),new int[]{255, 255, 255});
        colors.put(Short.valueOf("1"),new int[]{255, 0, 0});
        colors.put(Short.valueOf("2"),new int[]{255, 255, 0});
        colors.put(Short.valueOf("3"),new int[]{0, 255, 0});
        colors.put(Short.valueOf("4"),new int[]{0, 255, 255});
        colors.put(Short.valueOf("5"),new int[]{0, 0, 255});
        colors.put(Short.valueOf("6"),new int[]{255,0,255});
        colors.put(Short.valueOf("7"),new int[]{255,255,255});
        colors.put(Short.valueOf("8"),new int[]{128,128,128});
        colors.put(Short.valueOf("9"),new int[]{192,192,192});
        colors.put(Short.valueOf("10"),new int[]{255, 0, 0});
        colors.put(Short.valueOf("11"),new int[]{255, 127, 127});
        colors.put(Short.valueOf("12"),new int[]{204, 0, 0});
        colors.put(Short.valueOf("13"),new int[]{204, 102, 102});
        colors.put(Short.valueOf("14"),new int[]{153, 0, 0});
        colors.put(Short.valueOf("15"),new int[]{153, 76, 76});
        colors.put(Short.valueOf("16"),new int[]{127, 0, 0});
        colors.put(Short.valueOf("17"),new int[]{127, 63, 63});
        colors.put(Short.valueOf("18"),new int[]{76, 0, 0});
        colors.put(Short.valueOf("19"),new int[]{76, 38, 38});
        colors.put(Short.valueOf("20"),new int[]{255, 63, 0});
        colors.put(Short.valueOf("21"),new int[]{255, 159, 127});
        colors.put(Short.valueOf("22"),new int[]{204, 51, 0});
        colors.put(Short.valueOf("23"),new int[]{204, 127, 102});
        colors.put(Short.valueOf("24"),new int[]{153, 38, 0});
        colors.put(Short.valueOf("26"),new int[]{127, 31, 0});
        colors.put(Short.valueOf("27"),new int[]{127, 79, 63});
        colors.put(Short.valueOf("28"),new int[]{76, 19, 0});
        colors.put(Short.valueOf("29"),new int[]{76, 47, 38});
        colors.put(Short.valueOf("31"),new int[]{255, 191, 127});
        colors.put(Short.valueOf("32"),new int[]{204, 102, 0});
        colors.put(Short.valueOf("33"),new int[]{204, 153, 102});
        colors.put(Short.valueOf("34"),new int[]{153, 76, 0});
        colors.put(Short.valueOf("35"),new int[]{153, 114, 76});
        colors.put(Short.valueOf("36"),new int[]{127, 63, 0});
        colors.put(Short.valueOf("37"),new int[]{127, 95, 63});
        colors.put(Short.valueOf("39"),new int[]{76, 57, 38});
        colors.put(Short.valueOf("40"),new int[]{255, 191, 0});
        colors.put(Short.valueOf("41"),new int[]{255, 223, 127});
        colors.put(Short.valueOf("42"),new int[]{204, 153, 0});
        colors.put(Short.valueOf("43"),new int[]{204, 178, 102});
        colors.put(Short.valueOf("44"),new int[]{153, 114, 0});
        colors.put(Short.valueOf("45"),new int[]{153, 133, 76});
        colors.put(Short.valueOf("46"),new int[]{127, 95, 0});
        colors.put(Short.valueOf("47"),new int[]{127, 111, 63});
        colors.put(Short.valueOf("48"),new int[]{76, 57, 0});
        colors.put(Short.valueOf("49"),new int[]{76, 66, 38});
        colors.put(Short.valueOf("25"),new int[]{153, 95, 76});
        colors.put(Short.valueOf("30"),new int[]{255, 127, 0});
        colors.put(Short.valueOf("38"),new int[]{76,38,0});
        colors.put(Short.valueOf("125"),new int[]{76, 153, 133});
        colors.put(Short.valueOf("253"),new int[]{173,173,173});
        colors.put(Short.valueOf("254"),new int[]{214, 214, 214});
        colors.put(Short.valueOf("255"),new int[]{255,255,255});
        colors.put(Short.valueOf("256"),new int[]{0,0,0});
        colors.put(Short.valueOf("50"),new int[]{255, 255, 0});
        colors.put(Short.valueOf("51"),new int[]{255, 255, 127});
        colors.put(Short.valueOf("52"),new int[]{204, 204, 0});
        colors.put(Short.valueOf("53"),new int[]{204, 204, 102});
        colors.put(Short.valueOf("54"), new int[]{153, 153, 0});
        colors.put(Short.valueOf("55"), new int[]{153, 153, 76});
        colors.put(Short.valueOf("56"), new int[]{127, 127, 0});
        colors.put(Short.valueOf("57"), new int[]{127, 127, 63});
        colors.put(Short.valueOf("58"), new int[]{76, 76, 0});
        colors.put(Short.valueOf("59"), new int[]{76, 76, 38});
        colors.put(Short.valueOf("60"), new int[]{191, 255, 0});
        colors.put(Short.valueOf("61"), new int[]{223, 255, 127});
        colors.put(Short.valueOf("62"), new int[]{153, 204, 0});
        colors.put(Short.valueOf("63"), new int[]{178, 204, 102});
        colors.put(Short.valueOf("64"), new int[]{114, 153, 0});
        colors.put(Short.valueOf("65"), new int[]{133, 153, 76});
        colors.put(Short.valueOf("66"), new int[]{95, 127, 0});
        colors.put(Short.valueOf("67"), new int[]{111, 127, 63});
        colors.put(Short.valueOf("68"), new int[]{57, 76, 0});
        colors.put(Short.valueOf("69"), new int[]{66, 76, 38});
        colors.put(Short.valueOf("70"), new int[]{127, 255, 0});
        colors.put(Short.valueOf("71"), new int[]{191, 255, 127});
        colors.put(Short.valueOf("72"), new int[]{102, 204, 0});
        colors.put(Short.valueOf("73"), new int[]{153, 204, 102});
        colors.put(Short.valueOf("74"), new int[]{76, 153, 0});
        colors.put(Short.valueOf("75"), new int[]{114, 153, 76});
        colors.put(Short.valueOf("76"), new int[]{63, 127, 0});
        colors.put(Short.valueOf("77"), new int[]{95, 127, 63});
        colors.put(Short.valueOf("78"), new int[]{38, 76, 0});
        colors.put(Short.valueOf("79"), new int[]{57, 76, 38});
        colors.put(Short.valueOf("80"), new int[]{63, 255, 0});
        colors.put(Short.valueOf("81"), new int[]{159, 255, 127});
        colors.put(Short.valueOf("82"), new int[]{51, 204, 0});
        colors.put(Short.valueOf("83"), new int[]{127, 204, 102});
        colors.put(Short.valueOf("84"), new int[]{38, 153, 0});
        colors.put(Short.valueOf("85"), new int[]{95, 153, 76});
        colors.put(Short.valueOf("86"), new int[]{31, 127, 0});
        colors.put(Short.valueOf("88"), new int[]{19, 76, 0});
        colors.put(Short.valueOf("89"), new int[]{47, 76, 38});
        colors.put(Short.valueOf("90"), new int[]{0, 255, 0});
        colors.put(Short.valueOf("91"), new int[]{127, 255, 127});
        colors.put(Short.valueOf("92"), new int[]{0, 204, 0});
        colors.put(Short.valueOf("93"), new int[]{102, 204, 102});
        colors.put(Short.valueOf("94"), new int[]{0, 153, 0});
        colors.put(Short.valueOf("95"), new int[]{76, 153, 76});
        colors.put(Short.valueOf("96"), new int[]{0, 127, 0});
        colors.put(Short.valueOf("97"), new int[]{63, 127, 63});
        colors.put(Short.valueOf("98"), new int[]{0, 76, 0});
        colors.put(Short.valueOf("99"), new int[]{38, 76, 38});
        colors.put(Short.valueOf("100"), new int[]{0, 255, 63});
        colors.put(Short.valueOf("101"), new int[]{127, 255, 159});
        colors.put(Short.valueOf("102"), new int[]{0, 204, 51});
        colors.put(Short.valueOf("103"), new int[]{102, 204, 127});
        colors.put(Short.valueOf("104"), new int[]{0, 153, 38});
        colors.put(Short.valueOf("105"), new int[]{76, 153, 95});
        colors.put(Short.valueOf("106"), new int[]{0, 127, 31});
        colors.put(Short.valueOf("107"), new int[]{63, 127, 79});
        colors.put(Short.valueOf("108"), new int[]{0, 76, 19});
        colors.put(Short.valueOf("109"), new int[]{38, 76, 47});
        colors.put(Short.valueOf("110"), new int[]{0, 255, 127});
        colors.put(Short.valueOf("111"), new int[]{127, 255, 191});
        colors.put(Short.valueOf("112"), new int[]{0, 204, 102});
        colors.put(Short.valueOf("113"), new int[]{102, 204, 153});
        colors.put(Short.valueOf("114"), new int[]{0, 153, 76});
        colors.put(Short.valueOf("115"), new int[]{76, 153, 114});
        colors.put(Short.valueOf("116"), new int[]{0, 127, 63});
        colors.put(Short.valueOf("117"), new int[]{63, 127, 95});
        colors.put(Short.valueOf("118"), new int[]{0, 76, 38});
        colors.put(Short.valueOf("119"), new int[]{38, 76, 57});
        colors.put(Short.valueOf("120"), new int[]{0, 255, 191});
        colors.put(Short.valueOf("121"), new int[]{127, 255, 223});
        colors.put(Short.valueOf("122"), new int[]{0, 204, 153});
        colors.put(Short.valueOf("123"), new int[]{102, 204, 178});
        colors.put(Short.valueOf("124"), new int[]{0, 153, 114});
        colors.put(Short.valueOf("126"), new int[]{0, 127, 95});
        colors.put(Short.valueOf("127"), new int[]{63, 127, 111});
        colors.put(Short.valueOf("128"), new int[]{0, 76, 57});
        colors.put(Short.valueOf("129"), new int[]{38, 76, 66});
        colors.put(Short.valueOf("130"), new int[]{0, 255, 255});
        colors.put(Short.valueOf("131"), new int[]{127, 255, 255});
        colors.put(Short.valueOf("132"), new int[]{0, 204, 204});
        colors.put(Short.valueOf("133"), new int[]{102, 204, 204});
        colors.put(Short.valueOf("134"), new int[]{0, 153, 153});
        colors.put(Short.valueOf("135"), new int[]{76, 153, 153});
        colors.put(Short.valueOf("136"), new int[]{0, 127, 127});
        colors.put(Short.valueOf("137"), new int[]{63, 127, 127});
        colors.put(Short.valueOf("138"), new int[]{0, 76, 76});
        colors.put(Short.valueOf("139"), new int[]{38, 76, 76});
        colors.put(Short.valueOf("140"), new int[]{0, 191, 255});
        colors.put(Short.valueOf("141"), new int[]{127, 223, 255});
        colors.put(Short.valueOf("142"), new int[]{0, 153, 204});
        colors.put(Short.valueOf("143"), new int[]{102, 178, 204});
        colors.put(Short.valueOf("144"), new int[]{0, 114, 153});
        colors.put(Short.valueOf("145"), new int[]{76, 133, 153});
        colors.put(Short.valueOf("146"), new int[]{0, 95, 127});
        colors.put(Short.valueOf("147"), new int[]{63, 111, 127});
        colors.put(Short.valueOf("148"), new int[]{0, 57, 76});
        colors.put(Short.valueOf("149"), new int[]{38, 66, 76});
        colors.put(Short.valueOf("150"), new int[]{0, 127, 255});
        colors.put(Short.valueOf("151"), new int[]{127, 191, 255});
        colors.put(Short.valueOf("152"), new int[]{0, 102, 204});
        colors.put(Short.valueOf("153"), new int[]{102, 153, 204});
        colors.put(Short.valueOf("154"), new int[]{0, 76, 153});
        colors.put(Short.valueOf("155"), new int[]{76, 114, 153});
        colors.put(Short.valueOf("156"), new int[]{0, 63, 127});
        colors.put(Short.valueOf("157"), new int[]{63, 95, 127});
        colors.put(Short.valueOf("158"), new int[]{0, 38, 76});
        colors.put(Short.valueOf("159"), new int[]{38, 57, 76});
        colors.put(Short.valueOf("160"), new int[]{0, 63, 255});
        colors.put(Short.valueOf("161"), new int[]{127, 159, 255});
        colors.put(Short.valueOf("162"), new int[]{0, 51, 204});
        colors.put(Short.valueOf("163"), new int[]{102, 127, 204});
        colors.put(Short.valueOf("164"), new int[]{0, 38, 153});
        colors.put(Short.valueOf("165"), new int[]{76, 95, 153});
        colors.put(Short.valueOf("166"), new int[]{0, 31, 127});
        colors.put(Short.valueOf("167"), new int[]{63, 79, 127});
        colors.put(Short.valueOf("168"), new int[]{0, 19, 76});
        colors.put(Short.valueOf("169"), new int[]{38, 47, 76});
        colors.put(Short.valueOf("170"), new int[]{0, 0, 255});
        colors.put(Short.valueOf("171"), new int[]{127, 127, 255});
        colors.put(Short.valueOf("172"), new int[]{0, 0, 204});
        colors.put(Short.valueOf("173"), new int[]{102, 102, 204});
        colors.put(Short.valueOf("174"), new int[]{0, 0, 153});
        colors.put(Short.valueOf("175"), new int[]{76, 76, 153});
        colors.put(Short.valueOf("176"), new int[]{0, 0, 127});
        colors.put(Short.valueOf("177"), new int[]{63, 63, 127});
        colors.put(Short.valueOf("178"), new int[]{0, 0, 76});
        colors.put(Short.valueOf("179"), new int[]{38, 38, 76});
        colors.put(Short.valueOf("180"), new int[]{63, 0, 255});
        colors.put(Short.valueOf("181"), new int[]{159, 127, 255});
        colors.put(Short.valueOf("182"), new int[]{51, 0, 204});
        colors.put(Short.valueOf("183"), new int[]{127, 102, 204});
        colors.put(Short.valueOf("184"), new int[]{38, 0, 153});
        colors.put(Short.valueOf("185"), new int[]{95, 76, 153});
        colors.put(Short.valueOf("186"), new int[]{31, 0, 127});
        colors.put(Short.valueOf("187"), new int[]{79, 63, 127});
        colors.put(Short.valueOf("188"), new int[]{19, 0, 76});
        colors.put(Short.valueOf("189"), new int[]{47, 38, 76});
        colors.put(Short.valueOf("190"), new int[]{127, 0, 255});
        colors.put(Short.valueOf("191"), new int[]{191, 127, 255});
        colors.put(Short.valueOf("192"), new int[]{102, 0, 204});
        colors.put(Short.valueOf("193"), new int[]{153, 102, 204});
        colors.put(Short.valueOf("194"), new int[]{76, 0, 153});
        colors.put(Short.valueOf("195"), new int[]{114, 76, 153});
        colors.put(Short.valueOf("196"), new int[]{63, 0, 127});
        colors.put(Short.valueOf("197"), new int[]{95, 63, 127});
        colors.put(Short.valueOf("198"), new int[]{38, 0, 76});
        colors.put(Short.valueOf("199"), new int[]{57, 38, 76});
        colors.put(Short.valueOf("200"), new int[]{191, 0, 255});
        colors.put(Short.valueOf("201"), new int[]{223, 127, 255});
        colors.put(Short.valueOf("202"), new int[]{153, 0, 204});
        colors.put(Short.valueOf("203"), new int[]{178, 102, 204});
        colors.put(Short.valueOf("204"), new int[]{114, 0, 153});
        colors.put(Short.valueOf("205"), new int[]{133, 76, 153});
        colors.put(Short.valueOf("206"), new int[]{95, 0, 127});
        colors.put(Short.valueOf("207"), new int[]{111, 63, 127});
        colors.put(Short.valueOf("208"), new int[]{57, 0, 76});
        colors.put(Short.valueOf("209"), new int[]{66, 38, 76});
        colors.put(Short.valueOf("210"), new int[]{255, 0, 255});
        colors.put(Short.valueOf("211"), new int[]{255, 127, 255});
        colors.put(Short.valueOf("212"), new int[]{204, 0, 204});
        colors.put(Short.valueOf("213"), new int[]{204, 102, 204});
        colors.put(Short.valueOf("214"), new int[]{153, 0, 153});
        colors.put(Short.valueOf("215"), new int[]{153, 76, 153});
        colors.put(Short.valueOf("216"), new int[]{127, 0, 127});
        colors.put(Short.valueOf("217"), new int[]{127, 63, 127});
        colors.put(Short.valueOf("218"), new int[]{76, 0, 76});
        colors.put(Short.valueOf("219"), new int[]{76, 38, 76});
        colors.put(Short.valueOf("220"), new int[]{255, 0, 191});
        colors.put(Short.valueOf("221"), new int[]{255, 127, 223});
        colors.put(Short.valueOf("222"), new int[]{204, 0, 153});
        colors.put(Short.valueOf("223"), new int[]{204, 102, 178});
        colors.put(Short.valueOf("224"), new int[]{153, 0, 114});
        colors.put(Short.valueOf("225"), new int[]{153, 76, 133});
        colors.put(Short.valueOf("226"), new int[]{127, 0, 95});
        colors.put(Short.valueOf("227"), new int[]{127, 63, 111});
        colors.put(Short.valueOf("228"), new int[]{76, 0, 57});
        colors.put(Short.valueOf("229"), new int[]{76, 38, 66});
        colors.put(Short.valueOf("230"), new int[]{255, 0, 127});
        colors.put(Short.valueOf("231"), new int[]{255, 127, 191});
        colors.put(Short.valueOf("232"), new int[]{204, 0, 102});
        colors.put(Short.valueOf("233"), new int[]{204, 102, 153});
        colors.put(Short.valueOf("234"), new int[]{153, 0, 76});
        colors.put(Short.valueOf("235"), new int[]{153, 76, 114});
        colors.put(Short.valueOf("236"), new int[]{127, 0, 63});
        colors.put(Short.valueOf("237"), new int[]{127, 63, 95});
        colors.put(Short.valueOf("238"), new int[]{76, 0, 38});
        colors.put(Short.valueOf("239"), new int[]{76, 38, 57});
        colors.put(Short.valueOf("240"), new int[]{255, 0, 63});
        colors.put(Short.valueOf("241"), new int[]{255, 127, 159});
        colors.put(Short.valueOf("242"), new int[]{204, 0, 51});
        colors.put(Short.valueOf("243"), new int[]{204, 102, 127});
        colors.put(Short.valueOf("244"), new int[]{153, 0, 38});
        colors.put(Short.valueOf("245"), new int[]{153, 76, 95});
        colors.put(Short.valueOf("246"), new int[]{127, 0, 31});
        colors.put(Short.valueOf("247"), new int[]{127, 63, 79});
        colors.put(Short.valueOf("248"), new int[]{76, 0, 19});
        colors.put(Short.valueOf("249"), new int[]{76, 38, 47});
        colors.put(Short.valueOf("250"), new int[]{51, 51, 51});
        colors.put(Short.valueOf("251"), new int[]{91, 91, 91});
        colors.put(Short.valueOf("252"), new int[]{132, 132, 132});
        return colors;
    }


    public AciColor(byte r, byte g, byte b)
    {
        this.index = RGBtoACI(r, g, b);
    }
    public AciColor(float r, float g, float b)
    {
        this.index = RGBtoACI((byte)(r * 255), (byte)(g * 255), (byte)(b * 255));
    }
    public AciColor(Color color)
    {
        this.index = RGBtoACI((byte)color.getRed(),(byte)color.getGreen(), (byte)color.getBlue());
        this.r = (short) AciColor.aciColors.get(index)[0];
        this.g = (short) AciColor.aciColors.get(index)[1];
        this.b = (short) AciColor.aciColors.get(index)[2];
    }
    public AciColor(short index)
    {
        if (index < 0 || index >= 256)
        {
            index=256;
        }
        if(index==0){
            index=0;
        }
        this.index = index;
        this.r = (short) AciColor.aciColors.get(index)[0];
        this.g = (short) AciColor.aciColors.get(index)[1];
        this.b = (short) AciColor.aciColors.get(index)[2];
    }
    private static byte RGBtoACI(byte r, byte g, byte b)
    {
        int prevDist = Integer.MAX_VALUE;
        byte index = 0;

        return index;
    }
    @Override
    public String toString()
    {
        if (this.index == 0)
            return "ByBlock";
        if (this.index == 256)
            return "ByLayer";
        return Short.toString(index);
    }

    
}
